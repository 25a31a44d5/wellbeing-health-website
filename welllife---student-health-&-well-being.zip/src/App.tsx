import React, { useState } from 'react';
import { ScreenId, UserHabit, AssessmentAnswers } from './types';
import { Header } from './components/Header';
import { NavigationDrawer } from './components/NavigationDrawer';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';

// Screens
import { HomeScreen } from './components/HomeScreen';
import { HealthAssessmentScreen } from './components/HealthAssessmentScreen';
import { HealthyHabitsScreen } from './components/HealthyHabitsScreen';
import { MentalWellnessScreen } from './components/MentalWellnessScreen';
import { SleepScreen } from './components/SleepScreen';
import { NutritionScreen } from './components/NutritionScreen';
import { ExerciseScreen } from './components/ExerciseScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { AboutScreen } from './components/AboutScreen';
import { ContactScreen } from './components/ContactScreen';

const INITIAL_HABITS: UserHabit[] = [
  {
    id: 'h-1',
    title: '500ml morning hydration upon waking',
    category: 'hydration',
    target: 'Upon Waking (8:00 AM)',
    completed: true,
    streakDays: 14,
  },
  {
    id: 'h-2',
    title: '10-minute courtyard natural sunlight exposure',
    category: 'sleep',
    target: 'Morning Melatonin Reset',
    completed: true,
    streakDays: 9,
  },
  {
    id: 'h-3',
    title: '3-minute seated desk stretch between lectures',
    category: 'movement',
    target: 'Post-Lecture Break',
    completed: true,
    streakDays: 6,
  },
  {
    id: 'h-4',
    title: 'Mid-afternoon whole-food brain snack',
    category: 'nutrition',
    target: '3:00 PM Study Sprint',
    completed: false,
    streakDays: 12,
  },
  {
    id: 'h-5',
    title: '2:00 PM caffeine curfew (protect deep sleep)',
    category: 'sleep',
    target: 'Before 2:00 PM',
    completed: true,
    streakDays: 14,
  },
  {
    id: 'h-6',
    title: '4-minute Navy SEAL Box Breathing reset',
    category: 'mindfulness',
    target: 'Library Study Session',
    completed: false,
    streakDays: 5,
  },
  {
    id: 'h-7',
    title: 'Phone screen warm Night-Shift mode by 9:30 PM',
    category: 'sleep',
    target: 'Evening Wind-Down',
    completed: false,
    streakDays: 11,
  },
];

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [habits, setHabits] = useState<UserHabit[]>(INITIAL_HABITS);
  const [streakCount, setStreakCount] = useState(14);
  const [overallScore, setOverallScore] = useState(84);
  const [assessmentAnswers, setAssessmentAnswers] = useState<AssessmentAnswers | null>({
    sleepQuality: 'good',
    stressLevel: 2,
    physicalActivity: '4 days/week',
    nutritionBalance: '7 glasses water/day',
    screenTimeHours: 7.5,
    mindfulnessFrequency: 'sometimes',
  });

  const handleNavigate = (screen: ScreenId) => {
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const nextCompleted = !h.completed;
          return {
            ...h,
            completed: nextCompleted,
            streakDays: nextCompleted ? h.streakDays + 1 : Math.max(0, h.streakDays - 1),
          };
        }
        return h;
      })
    );
  };

  const handleAddHabit = (newHabit: Omit<UserHabit, 'id' | 'completed' | 'streakDays'>) => {
    const habit: UserHabit = {
      ...newHabit,
      id: `h-${Date.now()}`,
      completed: false,
      streakDays: 1,
    };
    setHabits((prev) => [habit, ...prev]);
  };

  const handleSaveAssessment = (answers: AssessmentAnswers, score: number) => {
    setAssessmentAnswers(answers);
    setOverallScore(score);
  };

  return (
    <div className="min-h-screen flex flex-col bg-surface text-on-surface font-body selection:bg-primary-fixed selection:text-on-primary-fixed">
      {/* Top Header */}
      <Header
        currentScreen={currentScreen}
        onNavigate={handleNavigate}
        onOpenMenu={() => setIsMenuOpen(true)}
        streakCount={streakCount}
      />

      {/* Slide-out Navigation Drawer for all 10 screens */}
      <NavigationDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        currentScreen={currentScreen}
        onNavigate={handleNavigate}
      />

      {/* Screen Sub-header Bar / Breadcrumb / Quick Switcher */}
      <div className="bg-surface-container-low border-b border-surface-container px-4 lg:px-8 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-on-surface-variant">
            <button
              onClick={() => handleNavigate('home')}
              className="hover:text-primary transition-colors"
            >
              WellLife
            </button>
            <span>/</span>
            <span className="font-semibold text-on-surface capitalize">
              {currentScreen.replace('-', ' ')}
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto py-0.5 scrollbar-none">
            <span className="text-outline text-[11px] hidden sm:inline">Jump:</span>
            {[
              { id: 'home' as ScreenId, name: 'Home' },
              { id: 'healthy-habits' as ScreenId, name: 'Habits' },
              { id: 'health-assessment' as ScreenId, name: 'Assessment' },
              { id: 'sleep' as ScreenId, name: 'Sleep' },
              { id: 'mental-wellness' as ScreenId, name: 'Mental' },
              { id: 'nutrition' as ScreenId, name: 'Nutrition' },
              { id: 'exercise' as ScreenId, name: 'Movement' },
              { id: 'dashboard' as ScreenId, name: 'Dashboard' },
              { id: 'about' as ScreenId, name: 'UN SDG 3' },
              { id: 'contact' as ScreenId, name: 'Support' },
            ].map((scr) => (
              <button
                key={scr.id}
                onClick={() => handleNavigate(scr.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all shrink-0 ${
                  currentScreen === scr.id
                    ? 'bg-primary text-white font-semibold'
                    : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
                }`}
              >
                {scr.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Screen Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-8 transition-all">
        {currentScreen === 'home' && (
          <HomeScreen
            onNavigate={handleNavigate}
            habits={habits}
            streakCount={streakCount}
          />
        )}

        {currentScreen === 'health-assessment' && (
          <HealthAssessmentScreen
            onNavigate={handleNavigate}
            onSaveAssessment={handleSaveAssessment}
          />
        )}

        {currentScreen === 'healthy-habits' && (
          <HealthyHabitsScreen
            onNavigate={handleNavigate}
            habits={habits}
            onToggleHabit={handleToggleHabit}
            onAddHabit={handleAddHabit}
          />
        )}

        {currentScreen === 'mental-wellness' && (
          <MentalWellnessScreen onNavigate={handleNavigate} />
        )}

        {currentScreen === 'sleep' && (
          <SleepScreen onNavigate={handleNavigate} />
        )}

        {currentScreen === 'nutrition' && (
          <NutritionScreen onNavigate={handleNavigate} />
        )}

        {currentScreen === 'exercise' && (
          <ExerciseScreen onNavigate={handleNavigate} />
        )}

        {currentScreen === 'dashboard' && (
          <DashboardScreen
            onNavigate={handleNavigate}
            habits={habits}
            streakCount={streakCount}
            assessmentAnswers={assessmentAnswers}
            overallScore={overallScore}
          />
        )}

        {currentScreen === 'about' && (
          <AboutScreen onNavigate={handleNavigate} />
        )}

        {currentScreen === 'contact' && (
          <ContactScreen onNavigate={handleNavigate} />
        )}
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        currentScreen={currentScreen}
        onNavigate={handleNavigate}
        onOpenMenu={() => setIsMenuOpen(true)}
      />
    </div>
  );
}
