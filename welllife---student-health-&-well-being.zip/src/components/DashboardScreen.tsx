import React from 'react';
import { ScreenId, UserHabit, AssessmentAnswers } from '../types';
import { ASSETS } from '../data/assets';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenId) => void;
  habits: UserHabit[];
  streakCount: number;
  assessmentAnswers: AssessmentAnswers | null;
  overallScore: number;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  onNavigate,
  habits,
  streakCount,
  assessmentAnswers,
  overallScore,
}) => {
  const completedHabits = habits.filter((h) => h.completed).length;

  const weeklyData = [
    { day: 'Mon', score: 78, sleep: 7.2 },
    { day: 'Tue', score: 82, sleep: 7.5 },
    { day: 'Wed', score: 80, sleep: 7.0 },
    { day: 'Thu', score: 85, sleep: 7.8 },
    { day: 'Fri', score: 88, sleep: 8.0 },
    { day: 'Sat', score: 84, sleep: 8.2 },
    { day: 'Sun', score: overallScore, sleep: 7.7 },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Student Profile Card */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
          <div className="relative">
            <img
              src={ASSETS.alexAvatar}
              alt="Alex Morgan"
              className="w-24 h-24 rounded-full object-cover border-4 border-surface-container-high shadow-xs"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-1 right-1 w-5 h-5 bg-emerald-500 rounded-full ring-4 ring-white" />
          </div>

          <div className="space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h1 className="font-headline text-2xl sm:text-3xl font-bold text-on-surface">
                Alex Morgan
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Class of '26
              </span>
            </div>
            <p className="text-xs sm:text-sm text-on-surface-variant font-medium">
              B.S. Biomedical Engineering • University Campus West
            </p>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-1 text-xs text-on-surface-variant">
              <span className="flex items-center gap-1 font-semibold text-amber-700">
                <span className="material-symbols-outlined text-sm fill">local_fire_department</span>
                {streakCount} Day Consistency Streak
              </span>
              <span>•</span>
              <span className="text-emerald-700 font-semibold">
                Top 12% Campus Health Cohort
              </span>
            </div>
          </div>
        </div>

        {/* Holistic Score Badge */}
        <div className="flex items-center gap-4 bg-surface-container-low p-4 rounded-2xl border border-surface-container shrink-0">
          <div className="w-16 h-16 rounded-2xl bg-primary text-white flex items-center justify-center font-headline font-extrabold text-2xl shadow-md">
            {overallScore}
          </div>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-outline">
              Campus Health Index
            </div>
            <div className="font-headline font-bold text-sm text-on-surface">
              {overallScore >= 80 ? 'Optimal Vitality' : 'Moderate Wellness'}
            </div>
            <button
              onClick={() => onNavigate('health-assessment')}
              className="text-[11px] font-semibold text-primary hover:underline mt-0.5 block text-left"
            >
              Retake Assessment →
            </button>
          </div>
        </div>
      </div>

      {/* 4 Key Metrics Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-xs text-on-surface-variant mb-2 font-semibold">
            <span>Circadian Alignment</span>
            <span className="material-symbols-outlined text-indigo-600">bedtime</span>
          </div>
          <div className="font-headline text-3xl font-bold text-on-surface">
            91%
          </div>
          <p className="text-xs text-emerald-600 font-semibold mt-2">
            +4% vs last week
          </p>
          <span className="text-[11px] text-outline">Consistent 11:30 PM bedtime</span>
        </div>

        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-xs text-on-surface-variant mb-2 font-semibold">
            <span>Active Habits Today</span>
            <span className="material-symbols-outlined text-primary">fact_check</span>
          </div>
          <div className="font-headline text-3xl font-bold text-on-surface">
            {completedHabits}/{habits.length}
          </div>
          <p className="text-xs text-primary font-semibold mt-2">
            {Math.round((completedHabits / Math.max(habits.length, 1)) * 100)}% Complete
          </p>
          <button
            onClick={() => onNavigate('healthy-habits')}
            className="text-[11px] text-outline hover:text-primary transition-colors text-left block"
          >
            Manage Habit Checklist →
          </button>
        </div>

        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-xs text-on-surface-variant mb-2 font-semibold">
            <span>Cognitive Stress Load</span>
            <span className="material-symbols-outlined text-secondary">psychology</span>
          </div>
          <div className="font-headline text-3xl font-bold text-on-surface">
            {assessmentAnswers?.stressLevel ? `Level ${assessmentAnswers.stressLevel}/5` : 'Mild (2/5)'}
          </div>
          <p className="text-xs text-emerald-600 font-semibold mt-2">
            Regulated via Box Breathing
          </p>
          <span className="text-[11px] text-outline">Midterm season prep</span>
        </div>

        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-xs text-on-surface-variant mb-2 font-semibold">
            <span>UN SDG 3 Milestone</span>
            <span className="material-symbols-outlined text-emerald-600">verified</span>
          </div>
          <div className="font-headline text-3xl font-bold text-on-surface">
            Tier 2
          </div>
          <p className="text-xs text-on-surface-variant font-semibold mt-2">
            Good Health Ambassador
          </p>
          <span className="text-[11px] text-outline">14 days consecutive logs</span>
        </div>
      </div>

      {/* Weekly Trend Visualizer */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              Performance Analytics
            </span>
            <h3 className="font-headline text-xl font-bold text-on-surface">
              7-Day Well-Being Trajectory
            </h3>
          </div>
          <div className="flex items-center gap-3 text-xs text-on-surface-variant font-medium">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-primary inline-block"></span>
              Score (0-100)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-secondary inline-block"></span>
              Sleep (Hours)
            </span>
          </div>
        </div>

        {/* Bar/Trend Columns */}
        <div className="grid grid-cols-7 gap-2 sm:gap-4 pt-6 pb-2 items-end h-48 border-b border-surface-container">
          {weeklyData.map((d, i) => (
            <div key={i} className="flex flex-col items-center gap-2 h-full justify-end">
              <div className="w-full flex justify-center items-end gap-1 h-full">
                {/* Score bar */}
                <div
                  className="w-3 sm:w-5 bg-primary/90 hover:bg-primary rounded-t-md transition-all relative group"
                  style={{ height: `${d.score}%` }}
                >
                  <span className="absolute -top-7 left-1/2 -translate-x-1/2 bg-on-surface text-white text-[10px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                    Score: {d.score}
                  </span>
                </div>
                {/* Sleep bar */}
                <div
                  className="w-3 sm:w-5 bg-secondary/80 hover:bg-secondary rounded-t-md transition-all relative group"
                  style={{ height: `${(d.sleep / 10) * 100}%` }}
                >
                  <span className="absolute -top-7 left-1/2 -translate-x-1/2 bg-on-surface text-white text-[10px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                    Sleep: {d.sleep}h
                  </span>
                </div>
              </div>
              <span className="text-xs font-semibold text-on-surface-variant">
                {d.day}
              </span>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-on-surface-variant gap-2">
          <span>
            <strong>Average:</strong> 82.5 WellLife Score • 7.6 Hours Sleep / Night
          </span>
          <span className="text-emerald-700 font-semibold">
            Status: Neurocognitive function in prime zone
          </span>
        </div>
      </div>

      {/* 2-Column: Recommendations & Pillar Shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Personalized Recommendations */}
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-primary-fixed/40 text-on-primary-fixed flex items-center justify-center">
              <span className="material-symbols-outlined">auto_awesome</span>
            </div>
            <div>
              <h4 className="font-headline font-bold text-base text-on-surface">
                Personalized Next Steps for Alex
              </h4>
              <p className="text-xs text-on-surface-variant">Based on recent audit</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-on-surface-variant">
            <div className="p-3.5 rounded-2xl bg-surface-container-low border border-surface-container flex items-start gap-3">
              <span className="material-symbols-outlined text-primary text-lg">wb_sunny</span>
              <div>
                <strong className="text-on-surface block">Prioritize Morning Sunlight:</strong>
                Aim for 10 minutes outdoors before your 9 AM seminar to sustain alertness.
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-surface-container-low border border-surface-container flex items-start gap-3">
              <span className="material-symbols-outlined text-secondary text-lg">restaurant</span>
              <div>
                <strong className="text-on-surface block">Mid-Afternoon Protein Boost:</strong>
                Swap vending machine candy with overnight oats or Greek yogurt for stable blood glucose.
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-surface-container-low border border-surface-container flex items-start gap-3">
              <span className="material-symbols-outlined text-amber-600 text-lg">chair</span>
              <div>
                <strong className="text-on-surface block">Study Desk Posture:</strong>
                Complete the 5-minute seated spinal stretch between library study blocks.
              </div>
            </div>
          </div>
        </div>

        {/* Quick Launch Hub */}
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-secondary-container/30 text-secondary flex items-center justify-center">
              <span className="material-symbols-outlined">rocket_launch</span>
            </div>
            <div>
              <h4 className="font-headline font-bold text-base text-on-surface">
                Quick Action Launchpad
              </h4>
              <p className="text-xs text-on-surface-variant">Instant access to tools</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onNavigate('sleep')}
              className="p-3.5 rounded-2xl border border-surface-container-high hover:border-primary text-left transition-all bg-surface-container-low hover:bg-surface-container"
            >
              <span className="material-symbols-outlined text-xl text-secondary block mb-1">
                bedtime
              </span>
              <span className="font-bold text-xs text-on-surface block">Sleep Calculator</span>
              <span className="text-[10px] text-on-surface-variant">Sync 90-min alarm</span>
            </button>

            <button
              onClick={() => onNavigate('mental-wellness')}
              className="p-3.5 rounded-2xl border border-surface-container-high hover:border-primary text-left transition-all bg-surface-container-low hover:bg-surface-container"
            >
              <span className="material-symbols-outlined text-xl text-primary block mb-1">
                self_improvement
              </span>
              <span className="font-bold text-xs text-on-surface block">Box Breathing</span>
              <span className="text-[10px] text-on-surface-variant">Decompress in 4 mins</span>
            </button>

            <button
              onClick={() => onNavigate('nutrition')}
              className="p-3.5 rounded-2xl border border-surface-container-high hover:border-primary text-left transition-all bg-surface-container-low hover:bg-surface-container"
            >
              <span className="material-symbols-outlined text-xl text-amber-600 block mb-1">
                water_drop
              </span>
              <span className="font-bold text-xs text-on-surface block">Log Hydration</span>
              <span className="text-[10px] text-on-surface-variant">Drink 250ml glass</span>
            </button>

            <button
              onClick={() => onNavigate('exercise')}
              className="p-3.5 rounded-2xl border border-surface-container-high hover:border-primary text-left transition-all bg-surface-container-low hover:bg-surface-container"
            >
              <span className="material-symbols-outlined text-xl text-emerald-600 block mb-1">
                directions_walk
              </span>
              <span className="font-bold text-xs text-on-surface block">Desk Stretches</span>
              <span className="text-[10px] text-on-surface-variant">3-minute neck reset</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
