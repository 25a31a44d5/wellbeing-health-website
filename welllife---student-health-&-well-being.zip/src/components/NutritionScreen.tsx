import React, { useState } from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface NutritionScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const NutritionScreen: React.FC<NutritionScreenProps> = ({ onNavigate }) => {
  // Hydration state
  const [glassesLogged, setGlassesLogged] = useState(5);
  const targetGlasses = 8;
  const [selectedMeal, setSelectedMeal] = useState<number | null>(null);

  const recipes = [
    {
      id: 1,
      title: 'Power Protein Overnight Oats',
      tag: 'No Cook • Dorm Fridge',
      time: '5 mins prep',
      cost: '$1.40 / serving',
      image: ASSETS.recipeOats,
      calories: '380 kcal',
      protein: '22g Protein',
      ingredients: [
        '1/2 cup rolled oats',
        '1/2 cup Greek yogurt or plant milk',
        '1 tbsp chia seeds',
        '1 scoop protein powder (optional)',
        'Handful of blueberries or sliced banana',
        'Drizzle of honey or cinnamon',
      ],
      method:
        'Combine oats, milk, chia seeds, and yogurt in a mason jar. Stir thoroughly, seal, and refrigerate overnight. Top with fruit before your morning 8 AM lecture.',
    },
    {
      id: 2,
      title: 'Rainbow Quinoa Buddha Bowl',
      tag: 'Meal Prep • High Fiber',
      time: '15 mins',
      cost: '$2.80 / serving',
      image: ASSETS.recipeQuinoa,
      calories: '450 kcal',
      protein: '18g Protein',
      ingredients: [
        '1 cup cooked quinoa or brown rice',
        '1/2 can rinsed chickpeas (or roasted tofu)',
        '1/2 cup shredded purple cabbage & carrots',
        '1 cup baby spinach',
        '1/4 avocado or pumpkin seeds',
        '2 tbsp lemon tahini or olive oil vinaigrette',
      ],
      method:
        'Assemble cooked grains in a bowl. Arrange fresh vegetables and protein in color sections. Drizzle with tahini dressing for sustained mid-day brain power.',
    },
    {
      id: 3,
      title: 'Mediterranean Crunchy Hummus Wrap',
      tag: 'Quick Lunch • Portable',
      time: '6 mins',
      cost: '$2.10 / serving',
      image: ASSETS.recipeWrap,
      calories: '410 kcal',
      protein: '15g Protein',
      ingredients: [
        '1 whole grain tortilla wrap',
        '3 tbsp classic or garlic hummus',
        '1/2 cup diced cucumber & cherry tomatoes',
        '1/4 cup feta cheese or chickpeas',
        'Small handful of kalamata olives & crisp arugula',
      ],
      method:
        'Spread hummus generously across tortilla. Layer crisp cucumber, tomatoes, olives, and greens. Roll tightly, wrap in foil, and toss into your backpack for campus library study sessions.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[220px] sm:min-h-[260px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.nutritionCounter}
            alt="Whole Foods Student Nutrition"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Pillar 03 • Brain Nutrition
              </span>
              <span className="text-xs text-white/80">Low-Glycemic Brain Fuel</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              Nutrition & Hydration for Students
            </h1>
            <p className="text-xs sm:text-sm text-white/90">
              Fuel sustained cognitive clarity without expensive dining plans or reliance on high-sugar energy drinks.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Hydration Tracker */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-secondary">
              Daily Cognitive Fuel
            </span>
            <h2 className="font-headline text-2xl font-bold text-on-surface">
              Daily Hydration Station ({glassesLogged} / {targetGlasses} Glasses)
            </h2>
            <p className="text-xs text-on-surface-variant mt-1">
              Just a 2% drop in hydration impairs concentration and triggers study headaches.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setGlassesLogged((g) => Math.max(0, g - 1))}
              className="p-2 rounded-xl border border-surface-container-high hover:bg-surface-container text-on-surface-variant"
              title="Remove glass"
            >
              <span className="material-symbols-outlined text-lg">remove</span>
            </button>
            <button
              onClick={() => setGlassesLogged((g) => Math.min(12, g + 1))}
              className="px-4 py-2 rounded-xl bg-secondary text-white font-semibold text-xs hover:bg-secondary/90 flex items-center gap-1 shadow-xs"
            >
              <span className="material-symbols-outlined text-base">add</span>
              <span>Drink 250ml</span>
            </button>
          </div>
        </div>

        {/* Glasses Visual */}
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
          {Array.from({ length: targetGlasses }).map((_, idx) => {
            const isFilled = idx < glassesLogged;
            return (
              <button
                key={idx}
                onClick={() => setGlassesLogged(idx + 1)}
                className={`p-3 rounded-2xl border flex flex-col items-center justify-center transition-all ${
                  isFilled
                    ? 'bg-sky-100 border-sky-300 text-secondary'
                    : 'bg-surface-container-low border-surface-container-high text-outline hover:bg-surface-container'
                }`}
              >
                <span className="material-symbols-outlined text-2xl">
                  {isFilled ? 'water_full' : 'water_loss'}
                </span>
                <span className="text-[11px] font-bold mt-1">Glass {idx + 1}</span>
                <span className="text-[10px] text-on-surface-variant">250ml</span>
              </button>
            );
          })}
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between p-3.5 rounded-2xl bg-surface-container-low text-xs text-on-surface-variant gap-2">
          <span>
            Total logged: <strong>{(glassesLogged * 0.25).toFixed(2)} Liters</strong> • Recommended target: 2.0 Liters
          </span>
          {glassesLogged >= targetGlasses && (
            <span className="text-emerald-700 font-semibold flex items-center gap-1">
              <span className="material-symbols-outlined text-sm">check_circle</span>
              Target achieved! Excellent brain hydration.
            </span>
          )}
        </div>
      </div>

      {/* Dorm-Friendly Recipes */}
      <div className="space-y-4">
        <div>
          <h3 className="font-headline text-2xl font-bold text-on-surface">
            Budget-Friendly Dorm Brain Meals
          </h3>
          <p className="text-sm text-on-surface-variant">
            Under $3 per portion. Minimal utensils required, balanced for lasting study stamina.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {recipes.map((item) => (
            <div
              key={item.id}
              className="bg-surface-container-lowest rounded-3xl border border-surface-container-high overflow-hidden shadow-xs flex flex-col hover:border-primary/40 transition-all"
            >
              <div className="h-44 overflow-hidden relative">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-black/60 text-white text-[11px] font-semibold backdrop-blur-xs">
                  {item.tag}
                </span>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h4 className="font-headline font-bold text-base text-on-surface">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-3 text-xs text-on-surface-variant mt-1.5 font-medium">
                    <span className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm text-primary">schedule</span>
                      {item.time}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-700 font-bold">{item.cost}</span>
                  </div>

                  <div className="flex items-center gap-2 mt-2">
                    <span className="px-2 py-0.5 rounded-md bg-surface-container text-[11px] font-semibold text-on-surface">
                      {item.calories}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-primary-fixed/50 text-[11px] font-semibold text-on-primary-fixed">
                      {item.protein}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedMeal(selectedMeal === item.id ? null : item.id)}
                  className="w-full py-2.5 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-primary font-semibold text-xs transition-colors flex items-center justify-center gap-1"
                >
                  <span>{selectedMeal === item.id ? 'Close Details' : 'View Recipe & Steps'}</span>
                  <span className="material-symbols-outlined text-sm">
                    {selectedMeal === item.id ? 'expand_less' : 'expand_more'}
                  </span>
                </button>

                {selectedMeal === item.id && (
                  <div className="pt-3 border-t border-surface-container text-xs text-on-surface-variant space-y-3 animate-in fade-in">
                    <div>
                      <strong className="text-on-surface block mb-1">Key Ingredients:</strong>
                      <ul className="list-disc list-inside space-y-0.5 text-[11px]">
                        {item.ingredients.map((ing, i) => (
                          <li key={i}>{ing}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <strong className="text-on-surface block mb-1">Preparation:</strong>
                      <p className="text-[11px] leading-relaxed">{item.method}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
