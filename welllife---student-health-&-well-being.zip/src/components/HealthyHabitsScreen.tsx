import React, { useState } from 'react';
import { ScreenId, UserHabit } from '../types';
import { ASSETS } from '../data/assets';

interface HealthyHabitsScreenProps {
  onNavigate: (screen: ScreenId) => void;
  habits: UserHabit[];
  onToggleHabit: (id: string) => void;
  onAddHabit: (habit: Omit<UserHabit, 'id' | 'completed' | 'streakDays'>) => void;
}

export const HealthyHabitsScreen: React.FC<HealthyHabitsScreenProps> = ({
  onNavigate,
  habits,
  onToggleHabit,
  onAddHabit,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<UserHabit['category']>('mindfulness');
  const [newTarget, setNewTarget] = useState('');

  const filteredHabits =
    selectedCategory === 'all'
      ? habits
      : habits.filter((h) => h.category === selectedCategory);

  const completedCount = habits.filter((h) => h.completed).length;
  const completionRate = Math.round((completedCount / Math.max(habits.length, 1)) * 100);

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddHabit({
      title: newTitle.trim(),
      category: newCategory,
      target: newTarget.trim() || 'Daily',
    });
    setNewTitle('');
    setNewTarget('');
    setIsAdding(false);
  };

  const getCategoryIcon = (cat: UserHabit['category']) => {
    switch (cat) {
      case 'sleep':
        return 'bedtime';
      case 'hydration':
        return 'water_drop';
      case 'movement':
        return 'directions_run';
      case 'mindfulness':
        return 'self_improvement';
      case 'nutrition':
        return 'restaurant';
    }
  };

  const getCategoryColor = (cat: UserHabit['category']) => {
    switch (cat) {
      case 'sleep':
        return 'text-indigo-600 bg-indigo-50 border-indigo-200';
      case 'hydration':
        return 'text-sky-600 bg-sky-50 border-sky-200';
      case 'movement':
        return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'mindfulness':
        return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'nutrition':
        return 'text-rose-600 bg-rose-50 border-rose-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Banner with Habits Students Image */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[220px] sm:min-h-[260px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.habitsStudents}
            alt="University Students Outdoors"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Daily Discipline
              </span>
              <span className="text-xs text-white/80">Aligned with UN SDG Target 3.4</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              Circadian & Academic Daily Habits
            </h1>
            <p className="text-xs sm:text-sm text-white/90">
              Small, repeatable routines protect your mental bandwidth and prevent late-term burnout.
            </p>
          </div>
        </div>
      </div>

      {/* Progress Card */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <span className="text-xs font-bold uppercase tracking-wider text-outline">
            Today's Trajectory
          </span>
          <h2 className="font-headline text-2xl font-bold text-on-surface">
            {completedCount} of {habits.length} Habits Completed
          </h2>
          <p className="text-xs text-on-surface-variant">
            {completionRate === 100
              ? 'Incredible! You completed all scheduled habits today.'
              : completionRate >= 50
              ? 'Great momentum. Complete your evening wind-down to seal the streak.'
              : 'Keep going! Check off routines as you move through lectures.'}
          </p>
        </div>

        {/* Circular / Bar Gauge */}
        <div className="flex items-center gap-4">
          <div className="relative w-20 h-20 rounded-full flex items-center justify-center bg-surface-container-high">
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: `conic-gradient(#006948 ${completionRate * 3.6}deg, #eaedff 0deg)`,
              }}
            />
            <div className="absolute inset-2 bg-surface-container-lowest rounded-full flex items-center justify-center font-headline font-bold text-sm text-primary">
              {completionRate}%
            </div>
          </div>
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-4 py-2.5 rounded-2xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <span className="material-symbols-outlined text-base">
              {isAdding ? 'close' : 'add'}
            </span>
            <span>{isAdding ? 'Cancel' : 'New Habit'}</span>
          </button>
        </div>
      </div>

      {/* Add Custom Habit Form */}
      {isAdding && (
        <form
          onSubmit={handleCreateHabit}
          className="bg-surface-container-lowest rounded-3xl border border-primary/30 p-6 space-y-4 shadow-sm animate-in fade-in"
        >
          <h3 className="font-headline text-base font-bold text-on-surface">
            Add a New Daily Health Habit
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-on-surface-variant mb-1">
                Habit Name
              </label>
              <input
                type="text"
                placeholder="e.g., 10-minute courtyard walk after lunch"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                required
                className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-on-surface-variant mb-1">
                Category
              </label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary bg-surface-container-lowest"
              >
                <option value="sleep">Sleep & Circadian</option>
                <option value="hydration">Hydration</option>
                <option value="movement">Movement & Exercise</option>
                <option value="mindfulness">Mindfulness & Stress</option>
                <option value="nutrition">Nutrition</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface-variant mb-1">
              Target Timing or Note
            </label>
            <input
              type="text"
              placeholder="e.g., Every day at 1:30 PM"
              value={newTarget}
              onChange={(e) => setNewTarget(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 rounded-xl text-xs font-medium text-on-surface-variant hover:bg-surface-container"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-primary text-white font-semibold text-xs hover:bg-primary-container"
            >
              Add Habit
            </button>
          </div>
        </form>
      )}

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {[
          { id: 'all', label: 'All Habits', count: habits.length },
          { id: 'sleep', label: 'Sleep & Night', count: habits.filter((h) => h.category === 'sleep').length },
          { id: 'hydration', label: 'Hydration', count: habits.filter((h) => h.category === 'hydration').length },
          { id: 'movement', label: 'Movement', count: habits.filter((h) => h.category === 'movement').length },
          { id: 'mindfulness', label: 'Mindfulness', count: habits.filter((h) => h.category === 'mindfulness').length },
          { id: 'nutrition', label: 'Nutrition', count: habits.filter((h) => h.category === 'nutrition').length },
        ].map((pill) => (
          <button
            key={pill.id}
            onClick={() => setSelectedCategory(pill.id)}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              selectedCategory === pill.id
                ? 'bg-primary text-white shadow-xs'
                : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
            }`}
          >
            {pill.label} ({pill.count})
          </button>
        ))}
      </div>

      {/* Habits List */}
      <div className="space-y-3">
        {filteredHabits.map((habit) => {
          const badgeStyle = getCategoryColor(habit.category);
          return (
            <div
              key={habit.id}
              onClick={() => onToggleHabit(habit.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                habit.completed
                  ? 'bg-primary-fixed/20 border-primary/30 text-on-surface'
                  : 'bg-surface-container-lowest border-surface-container-high hover:border-surface-container-highest'
              }`}
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <button
                  type="button"
                  aria-label={`Toggle habit ${habit.title}`}
                  className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all ${
                    habit.completed
                      ? 'bg-primary border-primary text-white'
                      : 'border-outline-variant bg-surface-container-lowest text-transparent hover:border-primary'
                  }`}
                >
                  <span className="material-symbols-outlined text-base">check</span>
                </button>

                <div className="min-w-0">
                  <h4
                    className={`text-sm font-semibold truncate ${
                      habit.completed ? 'line-through text-on-surface-variant' : 'text-on-surface'
                    }`}
                  >
                    {habit.title}
                  </h4>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-on-surface-variant">
                    <span className="capitalize">{habit.target}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1 text-amber-700 font-medium">
                      <span className="material-symbols-outlined text-xs fill">local_fire_department</span>
                      {habit.streakDays}d streak
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span
                  className={`hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${badgeStyle}`}
                >
                  <span className="material-symbols-outlined text-xs">
                    {getCategoryIcon(habit.category)}
                  </span>
                  <span className="capitalize">{habit.category}</span>
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Helper Banner */}
      <div className="p-5 rounded-2xl bg-surface-container border border-surface-container-high text-xs text-on-surface-variant flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-primary text-2xl">lightbulb</span>
          <span>
            <strong>Circadian Science Tip:</strong> Exposure to 10 minutes of morning daylight triggers serotonin synthesis and starts your 14-hour countdown clock for natural melatonin release at bedtime.
          </span>
        </div>
        <button
          onClick={() => onNavigate('sleep')}
          className="whitespace-nowrap font-semibold text-primary hover:underline text-xs"
        >
          View Sleep Tools →
        </button>
      </div>
    </div>
  );
};
