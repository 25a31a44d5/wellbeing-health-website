import React, { useState } from 'react';
import { ScreenId } from '../types';

interface ContactScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ContactScreen: React.FC<ContactScreenProps> = ({ onNavigate }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('mental-health');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;
    setSubmitted(true);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Banner */}
      <div className="bg-secondary-container/20 rounded-3xl border border-secondary/30 p-6 sm:p-8 space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary text-white text-xs font-semibold">
          <span className="material-symbols-outlined text-sm">support_agent</span>
          <span>Student Health & Counseling Services</span>
        </div>
        <h1 className="font-headline text-2xl sm:text-3xl font-bold text-on-surface">
          Student Support & Campus Care Directory
        </h1>
        <p className="text-xs sm:text-sm text-on-surface-variant max-w-2xl leading-relaxed">
          You are never alone on this campus. Whether you need confidential counseling, guidance on chronic insomnia, or dietary advice, free student resources are readily available.
        </p>
      </div>

      {/* 24/7 Immediate Crisis Resources Card */}
      <div className="bg-error-container/20 border border-error/30 rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-error text-white flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined">emergency</span>
          </div>
          <div>
            <h2 className="font-headline font-bold text-lg text-on-surface">
              24/7 Immediate Confidential Crisis Support
            </h2>
            <p className="text-xs text-on-surface-variant">
              Free, confidential, and available at any hour of the day or night.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="p-4 rounded-2xl bg-surface-container-lowest border border-surface-container-high space-y-1.5 shadow-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-error block">
              National Lifeline
            </span>
            <div className="font-headline font-extrabold text-xl text-on-surface">
              Call or Text 988
            </div>
            <p className="text-[11px] text-on-surface-variant">
              Available nationwide across the US & Canada for immediate mental health crises.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-surface-container-lowest border border-surface-container-high space-y-1.5 shadow-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-secondary block">
              Crisis Text Line
            </span>
            <div className="font-headline font-extrabold text-xl text-on-surface">
              Text HOME to 741741
            </div>
            <p className="text-[11px] text-on-surface-variant">
              Connect with a trained volunteer crisis counselor via free SMS.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-surface-container-lowest border border-surface-container-high space-y-1.5 shadow-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-primary block">
              Campus Security & Nurse
            </span>
            <div className="font-headline font-extrabold text-xl text-on-surface">
              (555) 019-CARE
            </div>
            <p className="text-[11px] text-on-surface-variant">
              Direct line to university health center after-hours triage nurse.
            </p>
          </div>
        </div>
      </div>

      {/* 2-Column: Appointment Booking Form & Campus Clinic Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Booking / Message Form */}
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div>
            <h3 className="font-headline font-bold text-lg text-on-surface">
              Request a Wellness Check-In
            </h3>
            <p className="text-xs text-on-surface-variant">
              Connect with a campus peer advisor or schedule a CAPS consultation.
            </p>
          </div>

          {submitted ? (
            <div className="p-6 rounded-2xl bg-primary-fixed/30 border border-primary/30 text-center space-y-3 animate-in fade-in">
              <div className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center mx-auto">
                <span className="material-symbols-outlined text-2xl">check</span>
              </div>
              <h4 className="font-headline font-bold text-base text-on-surface">
                Check-In Request Received!
              </h4>
              <p className="text-xs text-on-surface-variant">
                A student wellness coordinator will reach out to <strong>{email || 'your email'}</strong> within 24 hours. For urgent needs, please use the hotline numbers above.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSubmitted(false);
                  setMessage('');
                }}
                className="text-xs font-semibold text-primary underline"
              >
                Submit another request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-on-surface-variant mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Alex Morgan"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-on-surface-variant mb-1">
                  University Student Email
                </label>
                <input
                  type="email"
                  placeholder="alex.m@campus.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-on-surface-variant mb-1">
                  Support Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary bg-surface-container-lowest"
                >
                  <option value="mental-health">Stress & Academic Anxiety</option>
                  <option value="sleep">Chronic Insomnia / Circadian Sleep</option>
                  <option value="nutrition">Nutrition & Dorm Eating Habits</option>
                  <option value="exercise">Campus Movement & Rehabilitation</option>
                  <option value="peer">Peer Wellness Mentor Pairing</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-on-surface-variant mb-1">
                  How can the care team help?
                </label>
                <textarea
                  rows={3}
                  placeholder="Briefly describe what you are experiencing or your schedule preference..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high text-xs focus:outline-hidden focus:border-primary"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-colors shadow-xs"
              >
                Submit Confidential Request
              </button>
            </form>
          )}
        </div>

        {/* Clinic & Facility Info */}
        <div className="space-y-6">
          <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
            <h3 className="font-headline font-bold text-lg text-on-surface">
              Student Wellness Center Details
            </h3>

            <div className="space-y-3 text-xs text-on-surface-variant">
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-primary text-lg">location_on</span>
                <div>
                  <strong className="text-on-surface block">Main Campus Health Hall:</strong>
                  West Quad Building 4, Room 210, University Center
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-primary text-lg">schedule</span>
                <div>
                  <strong className="text-on-surface block">Drop-In Hours:</strong>
                  Monday – Thursday: 8:00 AM – 6:00 PM<br />
                  Friday: 8:00 AM – 4:30 PM<br />
                  Saturday: 10:00 AM – 2:00 PM (Urgent Care)
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-primary text-lg">verified_user</span>
                <div>
                  <strong className="text-on-surface block">Confidentiality Guarantee:</strong>
                  Medical and counseling consultations are protected under FERPA & HIPAA regulations. Never shared with academic faculty.
                </div>
              </div>
            </div>
          </div>

          <div className="bg-surface-container p-6 rounded-3xl border border-surface-container-high text-xs text-on-surface-variant space-y-2">
            <h4 className="font-headline font-bold text-sm text-on-surface">
              Peer Health Ambassador Program
            </h4>
            <p className="leading-relaxed">
              Prefer talking to a fellow student who understands exam pressure? WellLife peer ambassadors offer coffee walks, study-decompression chats, and sleep hygiene mentoring.
            </p>
            <button
              onClick={() => onNavigate('healthy-habits')}
              className="text-primary font-semibold text-xs hover:underline block pt-1"
            >
              Explore Daily Habits Checklist →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
