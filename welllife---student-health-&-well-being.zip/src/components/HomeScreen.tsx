import React from 'react';
import { ScreenId, UserHabit } from '../types';
import { ASSETS } from '../data/assets';

interface HomeScreenProps {
  onNavigate: (screen: ScreenId) => void;
  habits: UserHabit[];
  streakCount: number;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  habits,
  streakCount,
}) => {
  const completedHabits = habits.filter((h) => h.completed).length;
  const progressPercent = Math.round((completedHabits / Math.max(habits.length, 1)) * 100);

  return (
    <div className="space-y-10">
      {/* Hero Banner with Courtyard Image */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[360px] md:min-h-[420px] flex flex-col justify-end p-6 md:p-10 text-white">
          <img
            src={ASSETS.heroCourtyard}
            alt="University Courtyard Campus"
            className="absolute inset-0 w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Subtle gradient overlay for readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />

          {/* Top SDG Badge */}
          <div className="absolute top-6 left-6 flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold tracking-wide">
            <span className="w-2 h-2 rounded-full bg-primary-fixed"></span>
            <span>UN SDG 3: Good Health & Well-Being</span>
          </div>

          <div className="relative z-10 max-w-2xl space-y-3">
            <h1 className="font-headline text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight">
              Cultivating Vitality & Academic Resilience.
            </h1>
            <p className="text-white/90 text-sm sm:text-base leading-relaxed">
              University life demands stamina. WellLife bridges circadian science,
              stress mitigation, and wholesome habits to empower your degree and your body.
            </p>

            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => onNavigate('health-assessment')}
                className="px-5 py-2.5 rounded-2xl bg-primary-fixed text-on-primary-fixed font-semibold text-sm hover:bg-primary-fixed-dim active:scale-95 transition-all shadow-md flex items-center gap-2"
              >
                <span>Take Holistic Assessment</span>
                <span className="material-symbols-outlined text-base">arrow_forward</span>
              </button>

              <button
                onClick={() => onNavigate('healthy-habits')}
                className="px-5 py-2.5 rounded-2xl bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30 text-white font-semibold text-sm active:scale-95 transition-all flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-base">check_circle</span>
                <span>Today's Habits ({completedHabits}/{habits.length})</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Pulse & Quick Glance */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-on-surface-variant mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Habit Completion</span>
            <span className="material-symbols-outlined text-primary">fact_check</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-headline text-on-surface">
              {progressPercent}%
            </span>
            <span className="text-xs text-on-surface-variant font-medium">
              {completedHabits} of {habits.length} done
            </span>
          </div>
          <div className="w-full bg-surface-container-high h-2 rounded-full mt-3 overflow-hidden">
            <div
              className="bg-primary h-full rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-on-surface-variant mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Circadian Balance</span>
            <span className="material-symbols-outlined text-secondary">bedtime</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-headline text-on-surface">
              7h 45m
            </span>
            <span className="text-xs text-emerald-600 font-semibold">Optimal</span>
          </div>
          <p className="text-xs text-on-surface-variant mt-3">
            Natural melatonin alignment is high today.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-on-surface-variant mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Consistency Streak</span>
            <span className="material-symbols-outlined text-amber-600 fill">local_fire_department</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-headline text-on-surface">
              {streakCount} Days
            </span>
            <span className="text-xs text-on-surface-variant">Active</span>
          </div>
          <p className="text-xs text-on-surface-variant mt-3">
            Top 15% among university peers this semester.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container-high shadow-xs">
          <div className="flex items-center justify-between text-on-surface-variant mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Campus Wellness Index</span>
            <span className="material-symbols-outlined text-tertiary">health_and_safety</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-headline text-on-surface">
              84 / 100
            </span>
            <span className="text-xs text-emerald-600 font-semibold">+6 pts</span>
          </div>
          <p className="text-xs text-on-surface-variant mt-3">
            Comprehensive physical & mental assessment score.
          </p>
        </div>
      </div>

      {/* The 4 Core Pillars of Health Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-headline text-2xl font-bold text-on-surface">
              The Four WellLife Pillars
            </h2>
            <p className="text-sm text-on-surface-variant">
              Systematic lifestyle disciplines designed for collegiate cognitive performance.
            </p>
          </div>
          <button
            onClick={() => onNavigate('dashboard')}
            className="text-xs font-semibold text-primary hover:underline flex items-center gap-1"
          >
            <span>View Full Stats</span>
            <span className="material-symbols-outlined text-sm">chevron_right</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Pillar 1: Sleep */}
          <div className="rounded-2xl bg-surface-container-lowest border border-surface-container-high overflow-hidden flex flex-col hover:border-primary/40 transition-all shadow-xs group">
            <div className="h-36 overflow-hidden relative">
              <img
                src={ASSETS.sleepBedroom}
                alt="Circadian Sleep Environment"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-black/60 text-white text-[11px] font-semibold backdrop-blur-xs">
                Pillar 01
              </span>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <h3 className="font-headline font-bold text-base text-on-surface">
                  Sleep & Circadian Rhythm
                </h3>
                <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                  Harness 90-minute REM cycles, nighttime blue-light discipline, and consistent wake routines.
                </p>
              </div>
              <button
                onClick={() => onNavigate('sleep')}
                className="w-full py-2 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-primary font-semibold text-xs transition-colors flex items-center justify-center gap-1"
              >
                <span>Explore Sleep Tools</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>
          </div>

          {/* Pillar 2: Mental Wellness */}
          <div className="rounded-2xl bg-surface-container-lowest border border-surface-container-high overflow-hidden flex flex-col hover:border-primary/40 transition-all shadow-xs group">
            <div className="h-36 overflow-hidden relative">
              <img
                src={ASSETS.mentalLibrary}
                alt="Student Mental Calm in Library"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-black/60 text-white text-[11px] font-semibold backdrop-blur-xs">
                Pillar 02
              </span>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <h3 className="font-headline font-bold text-base text-on-surface">
                  Mental Wellness & Stress
                </h3>
                <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                  Box breathing breathwork, academic anxiety decompression, and campus counseling links.
                </p>
              </div>
              <button
                onClick={() => onNavigate('mental-wellness')}
                className="w-full py-2 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-primary font-semibold text-xs transition-colors flex items-center justify-center gap-1"
              >
                <span>Decompress Now</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>
          </div>

          {/* Pillar 3: Nutrition */}
          <div className="rounded-2xl bg-surface-container-lowest border border-surface-container-high overflow-hidden flex flex-col hover:border-primary/40 transition-all shadow-xs group">
            <div className="h-36 overflow-hidden relative">
              <img
                src={ASSETS.nutritionCounter}
                alt="Fresh Whole Nutrition Counter"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-black/60 text-white text-[11px] font-semibold backdrop-blur-xs">
                Pillar 03
              </span>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <h3 className="font-headline font-bold text-base text-on-surface">
                  Nutrition & Hydration
                </h3>
                <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                  Affordable dorm-friendly meals, brain-boosting hydration benchmarks, and simple recipes.
                </p>
              </div>
              <button
                onClick={() => onNavigate('nutrition')}
                className="w-full py-2 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-primary font-semibold text-xs transition-colors flex items-center justify-center gap-1"
              >
                <span>View Meal Plans</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>
          </div>

          {/* Pillar 4: Exercise */}
          <div className="rounded-2xl bg-surface-container-lowest border border-surface-container-high overflow-hidden flex flex-col hover:border-primary/40 transition-all shadow-xs group">
            <div className="h-36 overflow-hidden relative">
              <img
                src={ASSETS.exerciseWalking}
                alt="Daily Walking and Campus Movement"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-black/60 text-white text-[11px] font-semibold backdrop-blur-xs">
                Pillar 04
              </span>
            </div>
            <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
              <div>
                <h3 className="font-headline font-bold text-base text-on-surface">
                  Exercise & Movement
                </h3>
                <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                  Desk stretches, 10-minute micro workouts, and campus walking trails between lectures.
                </p>
              </div>
              <button
                onClick={() => onNavigate('exercise')}
                className="w-full py-2 px-3 rounded-xl bg-surface-container-low hover:bg-surface-container text-primary font-semibold text-xs transition-colors flex items-center justify-center gap-1"
              >
                <span>Start Stretch Routine</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* SDG 3 Impact Highlight Card */}
      <div className="rounded-3xl bg-surface-container p-6 md:p-8 border border-surface-container-high flex flex-col md:flex-row items-center gap-6">
        <div className="w-full md:w-1/3 max-w-[280px] rounded-2xl overflow-hidden shadow-md">
          <img
            src={ASSETS.sdg3Poster}
            alt="UN SDG 3 Good Health and Well-Being"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex-1 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold">
            <span className="material-symbols-outlined text-sm">public</span>
            <span>United Nations Global Goal</span>
          </div>
          <h3 className="font-headline text-2xl font-bold text-on-surface">
            Target 3.4: Promoting Mental Health & Well-Being in Higher Education
          </h3>
          <p className="text-sm text-on-surface-variant leading-relaxed">
            By reducing chronic sleep deficit, sedentary study blocks, and mental isolation,
            WellLife supports university communities in cultivating resilient scholars. Over
            65% of students report elevated semester anxiety; proactive daily prevention
            changes everything.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('about')}
              className="px-4 py-2 rounded-xl bg-primary text-on-primary font-semibold text-xs hover:bg-primary-container transition-colors flex items-center gap-1.5"
            >
              <span>Read WellLife SDG 3 Commitment</span>
              <span className="material-symbols-outlined text-sm">open_in_new</span>
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="px-4 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest hover:bg-surface-container text-xs font-semibold text-on-surface transition-colors"
            >
              Campus Student Support
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
