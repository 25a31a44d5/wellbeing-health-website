import React, { useState, useEffect } from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface MentalWellnessScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

type BreathingPhase = 'inhale' | 'hold1' | 'exhale' | 'hold2';

export const MentalWellnessScreen: React.FC<MentalWellnessScreenProps> = ({
  onNavigate,
}) => {
  // Box Breathing State
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [phase, setPhase] = useState<BreathingPhase>('inhale');
  const [secondsLeft, setSecondsLeft] = useState(4);
  const [cyclesCompleted, setCyclesCompleted] = useState(0);

  // Sound generator toggle (ambient student focus)
  const [activeSound, setActiveSound] = useState<string | null>(null);

  useEffect(() => {
    let timer: any = null;
    if (isBreathingActive) {
      timer = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // Transition phase
            setPhase((currentPhase) => {
              if (currentPhase === 'inhale') return 'hold1';
              if (currentPhase === 'hold1') return 'exhale';
              if (currentPhase === 'exhale') return 'hold2';
              setCyclesCompleted((c) => c + 1);
              return 'inhale';
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setSecondsLeft(4);
      setPhase('inhale');
    }
    return () => clearInterval(timer);
  }, [isBreathingActive]);

  const getPhaseInstruction = () => {
    switch (phase) {
      case 'inhale':
        return 'Inhale Deeply (Nose)';
      case 'hold1':
        return 'Hold with Stillness';
      case 'exhale':
        return 'Slow Exhale (Mouth)';
      case 'hold2':
        return 'Rest Empty';
    }
  };

  const getCircleScale = () => {
    if (!isBreathingActive) return 'scale-90';
    if (phase === 'inhale') return 'scale-125';
    if (phase === 'hold1') return 'scale-125';
    if (phase === 'exhale') return 'scale-90';
    return 'scale-90';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[220px] sm:min-h-[260px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.mentalLibrary}
            alt="University Library Study Calm"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Pillar 02 • Mental Wellness
              </span>
              <span className="text-xs text-white/80">Vagus Nerve Regulation</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              Mental Decompression & Academic Focus
            </h1>
            <p className="text-xs sm:text-sm text-white/90">
              Evidence-based autonomic nervous system downregulation to clear brain fog and manage exam anxiety.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Box Breathing Tool */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs flex flex-col items-center text-center space-y-6">
        <div className="max-w-md">
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            Physiological Reset
          </span>
          <h2 className="font-headline text-2xl font-bold text-on-surface">
            Navy SEAL Box Breathing (4-4-4-4)
          </h2>
          <p className="text-xs text-on-surface-variant mt-1">
            Equalizes sympathetic and parasympathetic tones in under 2 minutes. Ideal before exams or after grueling lectures.
          </p>
        </div>

        {/* Breathing Animation Canvas */}
        <div className="relative w-64 h-64 flex items-center justify-center my-4">
          {/* Outer Ripple Rings */}
          <div
            className={`absolute inset-0 rounded-full border border-primary/20 transition-all duration-1000 ${
              isBreathingActive ? 'animate-ping opacity-25' : 'opacity-10'
            }`}
          />
          <div
            className={`w-52 h-52 rounded-full bg-primary-fixed/30 border-2 border-primary/40 flex flex-col items-center justify-center transition-all duration-1000 transform ${getCircleScale()}`}
          >
            <span className="text-xs font-bold uppercase tracking-widest text-primary mb-1">
              {isBreathingActive ? phase : 'Ready'}
            </span>
            <span className="font-headline text-4xl font-extrabold text-on-surface">
              {isBreathingActive ? secondsLeft : '4s'}
            </span>
            <span className="text-xs font-medium text-on-surface-variant mt-1 px-4">
              {isBreathingActive ? getPhaseInstruction() : 'Press start to begin'}
            </span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => setIsBreathingActive(!isBreathingActive)}
            className={`px-8 py-3 rounded-2xl font-semibold text-xs transition-all shadow-sm flex items-center gap-2 ${
              isBreathingActive
                ? 'bg-surface-container-high text-on-surface hover:bg-surface-dim'
                : 'bg-primary text-white hover:bg-primary-container'
            }`}
          >
            <span className="material-symbols-outlined text-base">
              {isBreathingActive ? 'pause' : 'play_arrow'}
            </span>
            <span>{isBreathingActive ? 'Pause Exercise' : 'Begin 4-Minute Session'}</span>
          </button>

          {cyclesCompleted > 0 && (
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
              {cyclesCompleted} Cycles Completed
            </span>
          )}
        </div>
      </div>

      {/* 2-Column: Study Desk Decompression & Grounding */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: 5-4-3-2-1 Sensory Grounding */}
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-secondary-container/30 text-secondary flex items-center justify-center">
              <span className="material-symbols-outlined">visibility</span>
            </div>
            <div>
              <h3 className="font-headline font-bold text-base text-on-surface">
                5-4-3-2-1 Sensory Grounding
              </h3>
              <p className="text-xs text-on-surface-variant">Break acute cognitive spirals</p>
            </div>
          </div>
          <div className="space-y-2 text-xs text-on-surface-variant">
            <div className="p-2.5 rounded-xl bg-surface-container-low flex items-start gap-2.5">
              <span className="font-bold text-secondary text-sm">5</span>
              <span>Notice five items you see in your dorm or study room (a notebook, coffee mug, tree outside).</span>
            </div>
            <div className="p-2.5 rounded-xl bg-surface-container-low flex items-start gap-2.5">
              <span className="font-bold text-secondary text-sm">4</span>
              <span>Acknowledge four physical textures you can touch (desk wood, cotton shirt, smooth chair).</span>
            </div>
            <div className="p-2.5 rounded-xl bg-surface-container-low flex items-start gap-2.5">
              <span className="font-bold text-secondary text-sm">3</span>
              <span>Listen for three distinct auditory sounds (distant wind, typing, ventilation).</span>
            </div>
            <div className="p-2.5 rounded-xl bg-surface-container-low flex items-start gap-2.5">
              <span className="font-bold text-secondary text-sm">2</span>
              <span>Identify two scents in the air (paper, tea, crisp evening breeze).</span>
            </div>
            <div className="p-2.5 rounded-xl bg-surface-container-low flex items-start gap-2.5">
              <span className="font-bold text-secondary text-sm">1</span>
              <span>Taste one clean sensation (sip of cool water or mint).</span>
            </div>
          </div>
        </div>

        {/* Card 2: Ambient Study Soundscapes */}
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-tertiary-container/20 text-tertiary flex items-center justify-center">
              <span className="material-symbols-outlined">headphones</span>
            </div>
            <div>
              <h3 className="font-headline font-bold text-base text-on-surface">
                Campus Focus Soundscapes
              </h3>
              <p className="text-xs text-on-surface-variant">Low-frequency binaural study beats</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { id: 'rain', name: 'Rain on Glass', icon: 'rainy', desc: 'Dorm library drizzle' },
              { id: 'cafe', name: 'Campus Cafe', icon: 'local_cafe', desc: 'Subtle coffee shop buzz' },
              { id: 'forest', name: 'Pine Grove', icon: 'forest', desc: 'Outdoor wind & birds' },
              { id: 'binaural', name: 'Alpha Waves 10Hz', icon: 'graphic_eq', desc: 'Deep reading flow' },
            ].map((sound) => {
              const isActive = activeSound === sound.id;
              return (
                <button
                  key={sound.id}
                  onClick={() => setActiveSound(isActive ? null : sound.id)}
                  className={`p-3.5 rounded-2xl border text-left transition-all ${
                    isActive
                      ? 'border-primary bg-primary-fixed/30 text-on-surface ring-2 ring-primary/20'
                      : 'border-surface-container-high hover:bg-surface-container-low text-on-surface-variant'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="material-symbols-outlined text-lg text-primary">
                      {sound.icon}
                    </span>
                    {isActive && (
                      <span className="flex h-2 w-2 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                      </span>
                    )}
                  </div>
                  <div className="font-semibold text-xs text-on-surface">{sound.name}</div>
                  <div className="text-[10px] text-on-surface-variant mt-0.5">{sound.desc}</div>
                </button>
              );
            })}
          </div>

          <div className="p-3 rounded-xl bg-surface-container text-xs text-on-surface-variant flex items-center justify-between">
            <span>
              {activeSound
                ? `Playing ambient ${activeSound} track...`
                : 'Tap any soundscape to play focus audio background.'}
            </span>
            {activeSound && (
              <button
                onClick={() => setActiveSound(null)}
                className="text-primary font-bold text-[11px] underline ml-2"
              >
                Mute
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Campus Counseling Support Notice */}
      <div className="bg-secondary-container/20 border border-secondary/30 rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-2xl bg-secondary text-white flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined">support_agent</span>
          </div>
          <div>
            <h4 className="font-headline font-bold text-sm text-on-surface">
              Need Confidential Peer or Clinical Support?
            </h4>
            <p className="text-xs text-on-surface-variant mt-0.5">
              WellLife is connected with your University Counseling & Psychological Services (CAPS). Sessions are included with student tuition.
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('contact')}
          className="whitespace-nowrap px-4 py-2 rounded-xl bg-secondary text-white font-semibold text-xs hover:bg-secondary/90 transition-colors"
        >
          Book Confidential Consultation
        </button>
      </div>
    </div>
  );
};
