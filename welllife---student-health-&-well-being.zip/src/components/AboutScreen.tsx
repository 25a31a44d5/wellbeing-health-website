import React from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface AboutScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const AboutScreen: React.FC<AboutScreenProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Banner with Students in Sunlight */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[240px] sm:min-h-[280px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.aboutSunlight}
            alt="University Students in Morning Sunlight"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                United Nations Agenda 2030
              </span>
              <span className="text-xs text-white/80">Global Sustainable Goal 3</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              About WellLife & UN SDG 3
            </h1>
            <p className="text-xs sm:text-sm text-white/90">
              Ensure healthy lives and promote well-being for all at all ages — starting directly within university halls and colleges.
            </p>
          </div>
        </div>
      </div>

      {/* Mission & Framework */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div className="md:col-span-1 rounded-2xl overflow-hidden shadow-sm">
            <img
              src={ASSETS.sdg3Poster}
              alt="UN SDG 3 Good Health"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="md:col-span-2 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              The Higher Education Imperative
            </span>
            <h2 className="font-headline text-2xl font-bold text-on-surface">
              Why Student Health is a Global Priority
            </h2>
            <p className="text-xs sm:text-sm text-on-surface-variant leading-relaxed">
              Transitioning to university is one of life’s most vulnerable developmental junctures.
              Irregular sleep, academic stress, dietary volatility, and sedentariness often begin here,
              silently creating health deficits that persist into adulthood.
            </p>
            <p className="text-xs sm:text-sm text-on-surface-variant leading-relaxed">
              WellLife translates high-level United Nations guidelines into accessible, daily micro-actions
              that every student can practice without needing money, clinical equipment, or complex subscriptions.
            </p>
          </div>
        </div>

        {/* SDG Targets in Focus */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-surface-container">
          <div className="p-4 rounded-2xl bg-surface-container-low border border-surface-container space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-primary text-white text-[11px] font-bold">
                Target 3.4
              </span>
              <h4 className="font-headline font-bold text-sm text-on-surface">
                Mental Health & Non-Communicable Diseases
              </h4>
            </div>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              Promoting mental health awareness, autonomic breath regulation, and cardiovascular prevention through daily active campus walking and desk ergonomics.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-surface-container-low border border-surface-container space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-secondary text-white text-[11px] font-bold">
                Target 3.5
              </span>
              <h4 className="font-headline font-bold text-sm text-on-surface">
                Substance Prevention & Healthy Sleep Alternatives
              </h4>
            </div>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              Providing natural circadian biological alternatives to chronic stimulant / energy drink dependence and late-night cognitive burnout.
            </p>
          </div>
        </div>
      </div>

      {/* Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-primary-fixed/40 text-on-primary-fixed flex items-center justify-center">
            <span className="material-symbols-outlined">science</span>
          </div>
          <h3 className="font-headline font-bold text-base text-on-surface">
            Evidence-Based
          </h3>
          <p className="text-xs text-on-surface-variant leading-relaxed">
            Every breathing tempo, sleep cycle calculator, and dietary recommendation is grounded in peer-reviewed physiological research.
          </p>
        </div>

        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-secondary-container/30 text-secondary flex items-center justify-center">
            <span className="material-symbols-outlined">diversity_3</span>
          </div>
          <h3 className="font-headline font-bold text-base text-on-surface">
            Inclusive & Universal
          </h3>
          <p className="text-xs text-on-surface-variant leading-relaxed">
            Accessible to all students regardless of athletic background, dorm kitchen setup, or financial background.
          </p>
        </div>

        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-tertiary-container/20 text-tertiary flex items-center justify-center">
            <span className="material-symbols-outlined">lock</span>
          </div>
          <h3 className="font-headline font-bold text-base text-on-surface">
            Confidential & Free
          </h3>
          <p className="text-xs text-on-surface-variant leading-relaxed">
            Zero commercial ads, no selling of student health data. Fully dedicated to university community well-being.
          </p>
        </div>
      </div>

      {/* Call to Action */}
      <div className="p-6 rounded-3xl bg-primary-fixed/30 border border-primary/20 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="font-headline font-bold text-lg text-on-surface">
            Take Your First Step in the WellLife Journey
          </h4>
          <p className="text-xs text-on-surface-variant mt-0.5">
            Complete the 3-minute self-audit to discover your circadian rhythm profile.
          </p>
        </div>
        <button
          onClick={() => onNavigate('health-assessment')}
          className="whitespace-nowrap px-5 py-2.5 rounded-xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-colors shadow-xs"
        >
          Start Self-Assessment
        </button>
      </div>
    </div>
  );
};
