import React from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface FooterProps {
  onNavigate: (screen: ScreenId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-surface-container-low border-t border-surface-container-high py-12 px-4 lg:px-8 mt-16 pb-24 lg:pb-12 text-on-surface">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: Brand & SDG Mission */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <img
                src={ASSETS.logo}
                alt="WellLife Logo"
                className="w-9 h-9 object-contain rounded-xl"
                referrerPolicy="no-referrer"
              />
              <span className="font-headline font-bold text-xl text-primary">
                WellLife
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed">
                SDG 3 Initiative
              </span>
            </div>
            <p className="text-sm text-on-surface-variant max-w-md leading-relaxed">
              Empowering university students with scientific circadian sleep tracking,
              stress decompression routines, dorm-friendly nutrition, and active campus
              movement — directly advancing UN Sustainable Development Goal 3: Good Health & Well-Being.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <span className="inline-block w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-medium text-on-surface-variant">
                Confidential student health guidance • Peer verified
              </span>
            </div>
          </div>

          {/* Col 2: Navigation Pillars */}
          <div>
            <h4 className="font-headline font-bold text-xs uppercase tracking-wider text-outline mb-3">
              Wellness Pillars
            </h4>
            <ul className="space-y-2 text-sm text-on-surface-variant">
              <li>
                <button
                  onClick={() => onNavigate('sleep')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Sleep & Circadian Rhythm
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('mental-wellness')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Mental Health & Decompression
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('nutrition')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Brain Nutrition & Hydration
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('exercise')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Study Break Movement
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Student Care & Support */}
          <div>
            <h4 className="font-headline font-bold text-xs uppercase tracking-wider text-outline mb-3">
              Student Resources
            </h4>
            <ul className="space-y-2 text-sm text-on-surface-variant">
              <li>
                <button
                  onClick={() => onNavigate('health-assessment')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Holistic Self-Assessment
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('healthy-habits')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Daily Habit Checklist
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-primary transition-colors text-left"
                >
                  UN SDG 3 Commitment
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-primary transition-colors text-left font-medium text-secondary"
                >
                  Campus Crisis & Support Hub
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Crisis Notice Banner */}
        <div className="bg-surface-container border border-surface-container-high rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs text-on-surface-variant">
            <span className="material-symbols-outlined text-secondary text-2xl">emergency</span>
            <span>
              <strong>In crisis or need immediate support?</strong> Free, confidential 24/7 student mental health crisis hotline: Call or text <strong>988</strong> or text <strong>HOME to 741741</strong>.
            </span>
          </div>
          <button
            onClick={() => onNavigate('contact')}
            className="whitespace-nowrap px-3.5 py-1.5 rounded-xl bg-secondary-fixed text-on-secondary-fixed hover:bg-secondary-fixed-dim text-xs font-semibold transition-colors"
          >
            Get Help Now
          </button>
        </div>

        <div className="border-t border-surface-container-high mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-on-surface-variant gap-4">
          <p>© {new Date().getFullYear()} WellLife Initiative. Built for university student communities worldwide.</p>
          <div className="flex items-center gap-4">
            <span className="text-outline">Aligned with United Nations SDG Target 3.4 & 3.5</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
