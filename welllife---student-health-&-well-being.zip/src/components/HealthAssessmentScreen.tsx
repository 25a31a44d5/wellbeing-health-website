import React, { useState } from 'react';
import { ScreenId, AssessmentAnswers } from '../types';
import { ASSETS } from '../data/assets';

interface HealthAssessmentScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onSaveAssessment: (answers: AssessmentAnswers, score: number) => void;
}

export const HealthAssessmentScreen: React.FC<HealthAssessmentScreenProps> = ({
  onNavigate,
  onSaveAssessment,
}) => {
  const [step, setStep] = useState(1);
  const totalSteps = 5;

  // Form states
  const [sleepQuality, setSleepQuality] = useState<'poor' | 'fair' | 'good' | 'optimal'>('good');
  const [sleepHours, setSleepHours] = useState<number>(7);
  const [stressLevel, setStressLevel] = useState<number>(3); // 1 to 5
  const [exerciseDays, setExerciseDays] = useState<number>(3); // days per week
  const [waterGlasses, setWaterGlasses] = useState<number>(6); // glasses
  const [breaksTaken, setBreaksTaken] = useState<string>('sometimes');
  const [isCompleted, setIsCompleted] = useState(false);

  // Compute holistic score (out of 100)
  const calculateScore = () => {
    let score = 50;
    // Sleep factor
    if (sleepHours >= 7 && sleepHours <= 9) score += 15;
    else if (sleepHours === 6) score += 8;
    else score += 2;

    if (sleepQuality === 'optimal') score += 10;
    else if (sleepQuality === 'good') score += 7;
    else if (sleepQuality === 'fair') score += 4;

    // Stress factor (inverse)
    score += (5 - stressLevel) * 4;

    // Exercise
    score += Math.min(exerciseDays * 3, 12);

    // Water
    if (waterGlasses >= 8) score += 8;
    else if (waterGlasses >= 5) score += 5;
    else score += 2;

    // Breaks
    if (breaksTaken === 'frequently') score += 5;
    else if (breaksTaken === 'sometimes') score += 3;

    return Math.min(Math.max(score, 20), 100);
  };

  const finalScore = calculateScore();

  const handleFinish = () => {
    setIsCompleted(true);
    onSaveAssessment(
      {
        sleepQuality,
        stressLevel,
        physicalActivity: `${exerciseDays} days/week`,
        nutritionBalance: `${waterGlasses} glasses water/day`,
        screenTimeHours: 8,
        mindfulnessFrequency: breaksTaken,
      },
      finalScore
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[200px] sm:min-h-[240px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.assessmentJournal}
            alt="Student Assessment Journal"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Self-Audit Tool
              </span>
              <span className="text-xs text-white/80">Aligned with WHO & UN SDG 3</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              Holistic Student Health & Lifestyle Assessment
            </h1>
            <p className="text-xs sm:text-sm text-white/90 max-w-xl">
              Understand your baseline circadian sleep, exam stress triggers, hydration, and academic stamina in under 3 minutes.
            </p>
          </div>
        </div>
      </div>

      {/* Progress & Content Card */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs">
        {/* Step indicator */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-surface-container-high">
          <div>
            <span className="text-xs uppercase font-bold tracking-wider text-outline">
              Step {step} of {totalSteps}
            </span>
            <h2 className="font-headline text-lg font-bold text-on-surface">
              {step === 1 && 'Circadian Sleep Rhythm'}
              {step === 2 && 'Academic & Exam Stress Level'}
              {step === 3 && 'Movement & Physical Activity'}
              {step === 4 && 'Hydration & Nutrition Cadence'}
              {step === 5 && 'Study Breaks & Mindfulness'}
            </h2>
          </div>
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className={`h-2 rounded-full transition-all ${
                  i === step
                    ? 'w-6 bg-primary'
                    : i < step
                    ? 'w-2.5 bg-primary/40'
                    : 'w-2.5 bg-surface-container-high'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Step 1: Sleep */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-on-surface mb-2">
                On average, how many hours of continuous sleep do you get each night?
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="4"
                  max="11"
                  step="0.5"
                  value={sleepHours}
                  onChange={(e) => setSleepHours(parseFloat(e.target.value))}
                  className="w-full accent-primary h-2 bg-surface-container rounded-lg cursor-pointer"
                />
                <span className="font-headline font-bold text-lg text-primary w-20 text-right">
                  {sleepHours} hrs
                </span>
              </div>
              <p className="text-xs text-on-surface-variant mt-2">
                Optimal recommended range for university young adults is 7.5 to 8.5 hours.
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-on-surface mb-3">
                How refreshed do you feel 30 minutes after waking up?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { value: 'poor', label: 'Exhausted', icon: 'sentiment_very_dissatisfied' },
                  { value: 'fair', label: 'Sluggish', icon: 'sentiment_dissatisfied' },
                  { value: 'good', label: 'Alert', icon: 'sentiment_satisfied' },
                  { value: 'optimal', label: 'Energized', icon: 'sentiment_very_satisfied' },
                ].map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setSleepQuality(item.value as any)}
                    className={`p-3.5 rounded-2xl border text-center transition-all ${
                      sleepQuality === item.value
                        ? 'bg-primary-fixed/30 border-primary text-primary font-bold shadow-xs'
                        : 'border-surface-container-high hover:bg-surface-container-low text-on-surface-variant'
                    }`}
                  >
                    <span className="material-symbols-outlined text-2xl block mb-1">
                      {item.icon}
                    </span>
                    <span className="text-xs">{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Stress */}
        {step === 2 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-on-surface mb-2">
                Rate your average academic and coursework stress over the last 14 days:
              </label>
              <div className="grid grid-cols-5 gap-2 sm:gap-3 text-center my-4">
                {[1, 2, 3, 4, 5].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setStressLevel(lvl)}
                    className={`p-3 rounded-2xl border flex flex-col items-center transition-all ${
                      stressLevel === lvl
                        ? 'bg-secondary-container/40 border-secondary text-secondary font-bold ring-2 ring-secondary/20'
                        : 'border-surface-container-high hover:bg-surface-container-low text-on-surface-variant'
                    }`}
                  >
                    <span className="font-headline text-lg font-bold">{lvl}</span>
                    <span className="text-[10px] uppercase font-semibold mt-1">
                      {lvl === 1 && 'Minimal'}
                      {lvl === 2 && 'Mild'}
                      {lvl === 3 && 'Moderate'}
                      {lvl === 4 && 'High'}
                      {lvl === 5 && 'Severe'}
                    </span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-on-surface-variant">
                Academic pressure affects neuroplasticity and memory retention. Stress scoring helps customize your breathing intervals.
              </p>
            </div>
          </div>
        )}

        {/* Step 3: Movement */}
        {step === 3 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-on-surface mb-2">
                How many days per week do you get at least 25 minutes of intentional movement (walking, gym, sports, yoga)?
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="0"
                  max="7"
                  value={exerciseDays}
                  onChange={(e) => setExerciseDays(parseInt(e.target.value, 10))}
                  className="w-full accent-primary h-2 bg-surface-container rounded-lg cursor-pointer"
                />
                <span className="font-headline font-bold text-lg text-primary w-24 text-right">
                  {exerciseDays} days/wk
                </span>
              </div>
            </div>
            <div className="bg-surface-container-low p-4 rounded-2xl border border-surface-container text-xs text-on-surface-variant flex items-center gap-3">
              <span className="material-symbols-outlined text-primary text-2xl">directions_walk</span>
              <span>
                Even brisk 10-minute walks between campus lecture halls stimulate brain-derived neurotrophic factor (BDNF).
              </span>
            </div>
          </div>
        )}

        {/* Step 4: Hydration */}
        {step === 4 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-on-surface mb-3">
                How many glasses (approx 250ml) of water do you drink daily?
              </label>
              <div className="flex items-center gap-2 justify-center py-2">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setWaterGlasses(g)}
                    className={`w-9 h-11 rounded-xl flex flex-col items-center justify-center transition-all ${
                      g <= waterGlasses
                        ? 'bg-secondary text-white shadow-xs'
                        : 'bg-surface-container text-outline hover:bg-surface-container-high'
                    }`}
                  >
                    <span className="material-symbols-outlined text-xs">water_drop</span>
                    <span className="text-[10px] font-bold">{g}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-center text-on-surface-variant mt-2">
                Selected: <strong className="text-secondary">{waterGlasses} glasses</strong> (approx {(waterGlasses * 0.25).toFixed(1)} Liters)
              </p>
            </div>
          </div>
        )}

        {/* Step 5: Breaks */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-on-surface mb-3">
                Do you integrate structured 5-minute pauses or breathwork during prolonged study blocks?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'rarely', label: 'Rarely / Power Through', desc: 'Tend to study 3+ hours straight' },
                  { id: 'sometimes', label: 'Sometimes', desc: 'When mental fatigue hits' },
                  { id: 'frequently', label: 'Frequently', desc: 'Use Pomodoro or active stretch breaks' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setBreaksTaken(item.id)}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      breaksTaken === item.id
                        ? 'border-primary bg-primary-fixed/20 text-on-surface ring-2 ring-primary/20'
                        : 'border-surface-container-high hover:bg-surface-container-low text-on-surface-variant'
                    }`}
                  >
                    <div className="font-bold text-sm text-on-surface">{item.label}</div>
                    <div className="text-xs text-on-surface-variant mt-1">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Result Preview (if completed or final step) */}
        {isCompleted && (
          <div className="mt-8 p-6 rounded-3xl bg-primary-fixed/30 border border-primary/20 space-y-4 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-primary">
                  Assessment Complete
                </span>
                <h3 className="font-headline text-2xl font-bold text-on-surface">
                  Your Overall Well-Being Score: {finalScore} / 100
                </h3>
                <p className="text-xs text-on-surface-variant mt-1">
                  Status: {finalScore >= 80 ? 'Optimal Resilience' : finalScore >= 65 ? 'Moderate Balance' : 'Needs Routine Support'}
                </p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-primary text-white flex items-center justify-center font-headline font-extrabold text-2xl shadow-md">
                {finalScore}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="bg-surface-container-lowest p-3 rounded-xl border border-surface-container text-xs">
                <span className="text-outline block mb-0.5 font-medium">Sleep Cadence</span>
                <span className="font-semibold text-on-surface">{sleepHours}h ({sleepQuality})</span>
              </div>
              <div className="bg-surface-container-lowest p-3 rounded-xl border border-surface-container text-xs">
                <span className="text-outline block mb-0.5 font-medium">Stress Index</span>
                <span className="font-semibold text-on-surface">Level {stressLevel} of 5</span>
              </div>
              <div className="bg-surface-container-lowest p-3 rounded-xl border border-surface-container text-xs">
                <span className="text-outline block mb-0.5 font-medium">Weekly Movement</span>
                <span className="font-semibold text-on-surface">{exerciseDays} active days</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => onNavigate('dashboard')}
                className="px-5 py-2.5 rounded-xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-all flex items-center gap-1.5"
              >
                <span>View in Dashboard</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
              <button
                onClick={() => onNavigate('healthy-habits')}
                className="px-4 py-2.5 rounded-xl border border-surface-container-high bg-surface-container-lowest hover:bg-surface-container text-xs font-semibold text-on-surface"
              >
                Set Recommended Habits
              </button>
            </div>
          </div>
        )}

        {/* Action Controls */}
        {!isCompleted && (
          <div className="flex items-center justify-between pt-6 mt-6 border-t border-surface-container-high">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep((s) => s - 1)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-on-surface-variant hover:bg-surface-container transition-colors"
              >
                Back
              </button>
            ) : (
              <span />
            )}

            {step < totalSteps ? (
              <button
                type="button"
                onClick={() => setStep((s) => s + 1)}
                className="px-6 py-2.5 rounded-xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <span>Continue</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleFinish}
                className="px-6 py-2.5 rounded-xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-colors flex items-center gap-1.5 shadow-md"
              >
                <span>Calculate My Well-Being Score</span>
                <span className="material-symbols-outlined text-sm">done_all</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
