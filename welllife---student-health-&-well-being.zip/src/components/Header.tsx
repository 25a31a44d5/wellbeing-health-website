import React from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface HeaderProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  onOpenMenu: () => void;
  streakCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentScreen,
  onNavigate,
  onOpenMenu,
  streakCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-surface/90 backdrop-blur-md border-b border-surface-container-high px-4 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left: Brand & Menu toggle */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenMenu}
            className="p-2 -ml-2 rounded-xl text-on-surface hover:bg-surface-container active:scale-95 transition-all lg:hidden"
            aria-label="Open Navigation Menu"
          >
            <span className="material-symbols-outlined text-2xl">menu</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3 text-left group"
          >
            <img
              src={ASSETS.logo}
              alt="WellLife Logo"
              className="w-10 h-10 object-contain rounded-xl shadow-xs group-hover:scale-105 transition-transform"
              referrerPolicy="no-referrer"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-headline font-bold text-xl tracking-tight text-primary">
                  WellLife
                </span>
                <span className="hidden sm:inline-flex text-[11px] font-semibold uppercase tracking-wider bg-primary-fixed text-on-primary-fixed px-2 py-0.5 rounded-full">
                  SDG 3
                </span>
              </div>
              <p className="text-xs text-on-surface-variant hidden md:block">
                Student Health & Circadian Well-Being
              </p>
            </div>
          </button>
        </div>

        {/* Center: Desktop Quick Nav */}
        <nav className="hidden lg:flex items-center gap-1 bg-surface-container-low p-1.5 rounded-2xl border border-surface-container">
          <button
            onClick={() => onNavigate('home')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'home'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onNavigate('healthy-habits')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'healthy-habits'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Daily Habits
          </button>
          <button
            onClick={() => onNavigate('health-assessment')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'health-assessment'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Assessment
          </button>
          <button
            onClick={() => onNavigate('sleep')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'sleep'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Sleep
          </button>
          <button
            onClick={() => onNavigate('mental-wellness')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'mental-wellness'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Mental
          </button>
          <button
            onClick={() => onNavigate('nutrition')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'nutrition'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Nutrition
          </button>
          <button
            onClick={() => onNavigate('exercise')}
            className={`px-3.5 py-1.5 text-sm font-medium rounded-xl transition-all ${
              currentScreen === 'exercise'
                ? 'bg-surface-container-lowest text-primary shadow-xs font-semibold'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Movement
          </button>
        </nav>

        {/* Right Actions: Streak, All Screens Menu & Avatar */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-primary-fixed/60 border border-primary-fixed text-on-primary-fixed rounded-xl text-xs font-semibold">
            <span className="material-symbols-outlined text-base fill text-primary">local_fire_department</span>
            <span>{streakCount} Day Streak</span>
          </div>

          <button
            type="button"
            onClick={onOpenMenu}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-surface-container-high bg-surface-container-lowest hover:bg-surface-container text-xs font-medium text-on-surface transition-colors"
          >
            <span className="material-symbols-outlined text-base">apps</span>
            <span>All Screens</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 p-1 rounded-full border-2 border-primary/20 hover:border-primary transition-all relative group"
            title="View Student Dashboard"
          >
            <img
              src={ASSETS.alexAvatar}
              alt="Alex Student Profile"
              className="w-8 h-8 rounded-full object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-surface"></span>
          </button>
        </div>
      </div>
    </header>
  );
};
