import React, { useState, useEffect } from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface ExerciseScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const ExerciseScreen: React.FC<ExerciseScreenProps> = ({ onNavigate }) => {
  // Stretch routine timer state
  const [isStretching, setIsStretching] = useState(false);
  const [currentStretchIdx, setCurrentStretchIdx] = useState(0);
  const [stretchSecondsLeft, setStretchSecondsLeft] = useState(45);

  const stretches = [
    {
      name: 'Seated Spinal Twist',
      duration: 45,
      target: 'Spine & Lower Back',
      instructions: 'Sit tall in your desk chair. Inhale, lengthen your torso, place right hand on chair back and gently rotate left.',
    },
    {
      name: 'Suboccipital Neck Release',
      duration: 45,
      target: 'Neck & Upper Trapezius',
      instructions: 'Drop your right ear toward right shoulder. Place right hand gently atop head without pulling. Breathe into neck tension.',
    },
    {
      name: 'Typing Wrist & Forearm Extensor',
      duration: 45,
      target: 'Forearms & Carpal Tunnel',
      instructions: 'Extend arm straight out, palm forward. Gently pull fingers back toward torso with opposite hand to relieve keyboard cramp.',
    },
    {
      name: 'Standing Desk Quad & Hip Opener',
      duration: 45,
      target: 'Hip Flexors & Quads',
      instructions: 'Stand using your desk for balance. Grasp left ankle behind you, tuck tailbone slightly, and engage glutes to stretch hip flexors.',
    },
  ];

  useEffect(() => {
    let timer: any = null;
    if (isStretching) {
      timer = setInterval(() => {
        setStretchSecondsLeft((s) => {
          if (s <= 1) {
            if (currentStretchIdx < stretches.length - 1) {
              setCurrentStretchIdx((idx) => idx + 1);
              return stretches[currentStretchIdx + 1].duration;
            } else {
              setIsStretching(false);
              return 45;
            }
          }
          return s - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isStretching, currentStretchIdx]);

  const routines = [
    {
      title: 'Campus Brisk Walk & Daylight',
      image: ASSETS.exerciseWalking,
      tag: 'Cardio & Melatonin',
      time: '15-20 mins',
      benefit: 'Syncs circadian clock and burns 120 calories between lectures.',
    },
    {
      title: 'Desk Study Ergonomics & Stretch',
      image: ASSETS.exerciseStretching,
      tag: 'Mobility & Posture',
      time: '5 mins',
      benefit: 'Reverses forward-head posture caused by laptops and tablets.',
    },
    {
      title: 'Sunset Campus Perimeter Jog',
      image: ASSETS.exerciseJogging,
      tag: 'Aerobic Endurance',
      time: '25 mins',
      benefit: 'Elevates BDNF and sweeps out cortisol build-up from exams.',
    },
    {
      title: 'Bike to Campus Commute',
      image: ASSETS.exerciseCycling,
      tag: 'Active Transit',
      time: '15 mins',
      benefit: 'Zero-emission transport providing low-impact quad stimulation.',
    },
    {
      title: 'Dorm Yoga & Vinyasa Flow',
      image: ASSETS.exerciseYoga,
      tag: 'Flexibility & Calm',
      time: '15 mins',
      benefit: 'Lengthens tight hamstrings and primes parasympathetic nervous system.',
    },
    {
      title: 'No-Equipment Dorm Strength',
      image: ASSETS.exerciseBodyweight,
      tag: 'Bodyweight Resistance',
      time: '12 mins',
      benefit: 'Push-ups, squats, and planks without requiring a gym pass.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[220px] sm:min-h-[260px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.exerciseWalking}
            alt="Students Moving Outdoors"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Pillar 04 • Daily Movement
              </span>
              <span className="text-xs text-white/80">Active Campus Living</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              Exercise & Daily Movement
            </h1>
            <p className="text-xs sm:text-sm text-white/90">
              Break long sedentary study marathons. You don’t need 2 hours in a crowded gym to protect cardiovascular health.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive 5-Minute Desk Stretch Player */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-primary">
              Guided Micro-Break
            </span>
            <h2 className="font-headline text-2xl font-bold text-on-surface">
              Desk Stretch Routine ({currentStretchIdx + 1} of {stretches.length})
            </h2>
            <p className="text-xs text-on-surface-variant mt-1">
              Follow along right in your dorm chair to relieve neck spasms and wrist stiffness.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              if (isStretching) {
                setIsStretching(false);
              } else {
                setIsStretching(true);
              }
            }}
            className="px-6 py-2.5 rounded-2xl bg-primary text-white font-semibold text-xs hover:bg-primary-container transition-all flex items-center gap-2 shadow-xs"
          >
            <span className="material-symbols-outlined text-base">
              {isStretching ? 'pause' : 'play_arrow'}
            </span>
            <span>{isStretching ? 'Pause Routine' : 'Start 3-Minute Routine'}</span>
          </button>
        </div>

        {/* Current Active Stretch Box */}
        <div className="p-6 rounded-2xl bg-surface-container-low border border-surface-container flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-[11px] font-bold">
              Target: {stretches[currentStretchIdx].target}
            </span>
            <h3 className="font-headline text-2xl font-bold text-on-surface">
              {stretches[currentStretchIdx].name}
            </h3>
            <p className="text-xs text-on-surface-variant max-w-lg leading-relaxed">
              {stretches[currentStretchIdx].instructions}
            </p>
          </div>

          {/* Seconds Countdown */}
          <div className="w-24 h-24 rounded-2xl bg-surface-container-lowest border-2 border-primary flex flex-col items-center justify-center shadow-xs shrink-0">
            <span className="font-headline text-3xl font-extrabold text-primary">
              {stretchSecondsLeft}s
            </span>
            <span className="text-[10px] uppercase font-bold text-outline">
              Remaining
            </span>
          </div>
        </div>

        {/* Stretch Progress dots */}
        <div className="flex items-center justify-center gap-2">
          {stretches.map((s, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCurrentStretchIdx(idx);
                setStretchSecondsLeft(s.duration);
              }}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                idx === currentStretchIdx
                  ? 'bg-primary text-white'
                  : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
              }`}
            >
              Step {idx + 1}: {s.name.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* 6 Campus Movement Routines Grid */}
      <div className="space-y-4">
        <div>
          <h3 className="font-headline text-2xl font-bold text-on-surface">
            Collegiate Movement Routines
          </h3>
          <p className="text-sm text-on-surface-variant">
            Tailored for tight college schedules and minimal equipment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {routines.map((item, idx) => (
            <div
              key={idx}
              className="bg-surface-container-lowest rounded-3xl border border-surface-container-high overflow-hidden shadow-xs flex flex-col hover:border-primary/40 transition-all group"
            >
              <div className="h-40 overflow-hidden relative">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-black/60 text-white text-[11px] font-semibold backdrop-blur-xs">
                  {item.tag}
                </span>
                <span className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md bg-surface-container-lowest/90 text-on-surface text-[10px] font-bold backdrop-blur-xs">
                  {item.time}
                </span>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h4 className="font-headline font-bold text-base text-on-surface">
                    {item.title}
                  </h4>
                  <p className="text-xs text-on-surface-variant mt-1.5 leading-relaxed">
                    {item.benefit}
                  </p>
                </div>

                <div className="pt-2 border-t border-surface-container flex items-center justify-between text-xs">
                  <span className="text-primary font-semibold">Equipment: None</span>
                  <span className="material-symbols-outlined text-sm text-primary">arrow_forward</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
