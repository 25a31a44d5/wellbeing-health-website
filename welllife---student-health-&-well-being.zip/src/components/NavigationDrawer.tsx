import React from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

interface NavItem {
  id: ScreenId;
  title: string;
  description: string;
  icon: string;
  badge?: string;
  category: 'core' | 'pillars' | 'info';
}

const NAV_ITEMS: NavItem[] = [
  {
    id: 'home',
    title: 'Home Overview',
    description: 'Welcome portal & daily wellness snapshot',
    icon: 'home',
    category: 'core',
  },
  {
    id: 'healthy-habits',
    title: 'Daily Healthy Habits',
    description: 'Track daily circadian routines & streaks',
    icon: 'task_alt',
    badge: 'Daily',
    category: 'core',
  },
  {
    id: 'health-assessment',
    title: 'Health Assessment',
    description: 'Evidence-based holistic well-being audit',
    icon: 'assignment_turned_in',
    badge: 'Recommended',
    category: 'core',
  },
  {
    id: 'dashboard',
    title: 'Student Dashboard',
    description: 'Alex’s analytics, sleep score & academic balance',
    icon: 'insights',
    badge: 'Live',
    category: 'core',
  },
  {
    id: 'sleep',
    title: 'Sleep & Circadian Harmony',
    description: '90-min sleep cycles, bedtime calculator & sleep hygiene',
    icon: 'bedtime',
    badge: 'Pillar 1',
    category: 'pillars',
  },
  {
    id: 'mental-wellness',
    title: 'Mental Wellness & Stress',
    description: 'Box breathing, exam decompression & mindfulness audio',
    icon: 'self_improvement',
    badge: 'Pillar 2',
    category: 'pillars',
  },
  {
    id: 'nutrition',
    title: 'Nutrition & Hydration',
    description: 'Dorm-friendly brain food, budget meals & water tracker',
    icon: 'restaurant',
    badge: 'Pillar 3',
    category: 'pillars',
  },
  {
    id: 'exercise',
    title: 'Exercise & Daily Movement',
    description: 'Desk stretches, campus walks, study break routines',
    icon: 'directions_run',
    badge: 'Pillar 4',
    category: 'pillars',
  },
  {
    id: 'about',
    title: 'About WellLife & UN SDG 3',
    description: 'Good Health and Well-Being alignment and mission',
    icon: 'verified',
    category: 'info',
  },
  {
    id: 'contact',
    title: 'Student Support & Contact',
    description: 'Campus counselors, peer advisors & 24/7 crisis lines',
    icon: 'support_agent',
    badge: '24/7 Help',
    category: 'info',
  },
];

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  currentScreen,
  onNavigate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Slide-over panel */}
      <div className="fixed inset-y-0 left-0 max-w-sm w-full bg-surface-container-lowest shadow-2xl flex flex-col z-50 animate-in slide-in-from-left duration-200">
        {/* Header */}
        <div className="p-4 border-b border-surface-container-high flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <img
              src={ASSETS.logo}
              alt="WellLife"
              className="w-8 h-8 rounded-lg object-contain"
              referrerPolicy="no-referrer"
            />
            <div>
              <h2 className="font-headline font-bold text-base text-on-surface">
                All Application Screens
              </h2>
              <p className="text-xs text-on-surface-variant">
                10 Dedicated WellLife Spaces
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-colors"
          >
            <span className="material-symbols-outlined text-xl">close</span>
          </button>
        </div>

        {/* Scrollable Nav list */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-outline px-3 py-1">
              Core Experiences
            </div>
            <div className="space-y-1">
              {NAV_ITEMS.filter((item) => item.category === 'core').map((item) => {
                const isActive = currentScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      onClose();
                    }}
                    className={`w-full text-left p-2.5 rounded-xl flex items-center gap-3 transition-all ${
                      isActive
                        ? 'bg-primary-fixed/40 text-on-primary-fixed font-medium border border-primary/20'
                        : 'hover:bg-surface-container-low text-on-surface'
                    }`}
                  >
                    <span
                      className={`material-symbols-outlined text-xl ${
                        isActive ? 'text-primary' : 'text-on-surface-variant'
                      }`}
                    >
                      {item.icon}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-semibold truncate">
                          {item.title}
                        </div>
                        {item.badge && (
                          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-surface-container text-on-surface-variant">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-on-surface-variant truncate">
                        {item.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-outline px-3 py-1">
              Wellness Pillars
            </div>
            <div className="space-y-1">
              {NAV_ITEMS.filter((item) => item.category === 'pillars').map((item) => {
                const isActive = currentScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      onClose();
                    }}
                    className={`w-full text-left p-2.5 rounded-xl flex items-center gap-3 transition-all ${
                      isActive
                        ? 'bg-primary-fixed/40 text-on-primary-fixed font-medium border border-primary/20'
                        : 'hover:bg-surface-container-low text-on-surface'
                    }`}
                  >
                    <span
                      className={`material-symbols-outlined text-xl ${
                        isActive ? 'text-primary' : 'text-on-surface-variant'
                      }`}
                    >
                      {item.icon}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-semibold truncate">
                          {item.title}
                        </div>
                        {item.badge && (
                          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-on-surface-variant truncate">
                        {item.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-outline px-3 py-1">
              Mission & Support
            </div>
            <div className="space-y-1">
              {NAV_ITEMS.filter((item) => item.category === 'info').map((item) => {
                const isActive = currentScreen === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      onClose();
                    }}
                    className={`w-full text-left p-2.5 rounded-xl flex items-center gap-3 transition-all ${
                      isActive
                        ? 'bg-primary-fixed/40 text-on-primary-fixed font-medium border border-primary/20'
                        : 'hover:bg-surface-container-low text-on-surface'
                    }`}
                  >
                    <span
                      className={`material-symbols-outlined text-xl ${
                        isActive ? 'text-primary' : 'text-on-surface-variant'
                      }`}
                    >
                      {item.icon}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-semibold truncate">
                          {item.title}
                        </div>
                        {item.badge && (
                          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-error-container text-on-error-container">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-on-surface-variant truncate">
                        {item.description}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer SDG badge */}
        <div className="p-3 bg-surface-container-low border-t border-surface-container flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary text-white flex items-center justify-center font-bold text-sm shrink-0">
            3
          </div>
          <div className="text-xs text-on-surface-variant leading-tight">
            <span className="font-semibold text-on-surface block">UN SDG 3 Aligned</span>
            Ensuring healthy lives and promoting well-being for all university students.
          </div>
        </div>
      </div>
    </div>
  );
};
