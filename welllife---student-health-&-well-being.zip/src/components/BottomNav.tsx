import React from 'react';
import { ScreenId } from '../types';

interface BottomNavProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  onOpenMenu: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  onNavigate,
  onOpenMenu,
}) => {
  const tabs = [
    { id: 'home' as ScreenId, label: 'Home', icon: 'home' },
    { id: 'healthy-habits' as ScreenId, label: 'Habits', icon: 'task_alt' },
    { id: 'health-assessment' as ScreenId, label: 'Assess', icon: 'assignment_turned_in' },
    { id: 'sleep' as ScreenId, label: 'Sleep', icon: 'bedtime' },
    { id: 'dashboard' as ScreenId, label: 'Stats', icon: 'insights' },
  ];

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 lg:hidden bg-surface/90 backdrop-blur-lg border-t border-surface-container-high px-2 py-1.5 safe-area-pb">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = currentScreen === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all relative ${
                isActive
                  ? 'text-primary font-semibold'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span
                className={`material-symbols-outlined text-2xl transition-transform ${
                  isActive ? 'fill scale-110' : ''
                }`}
              >
                {tab.icon}
              </span>
              <span className="text-[11px] tracking-tight">{tab.label}</span>
              {isActive && (
                <span className="absolute -bottom-1 w-1 h-1 rounded-full bg-primary" />
              )}
            </button>
          );
        })}

        <button
          onClick={onOpenMenu}
          className="flex flex-col items-center justify-center py-1 px-3 rounded-xl text-on-surface-variant hover:text-on-surface transition-all"
        >
          <span className="material-symbols-outlined text-2xl">apps</span>
          <span className="text-[11px] tracking-tight">More</span>
        </button>
      </div>
    </div>
  );
};
