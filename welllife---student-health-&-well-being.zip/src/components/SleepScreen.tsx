import React, { useState } from 'react';
import { ScreenId } from '../types';
import { ASSETS } from '../data/assets';

interface SleepScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const SleepScreen: React.FC<SleepScreenProps> = ({ onNavigate }) => {
  // Calculator mode: calculate when to wake up if going to bed now, or when to sleep for a target wake time
  const [calcMode, setCalcMode] = useState<'wake' | 'sleep'>('wake');
  const [targetWakeTime, setTargetWakeTime] = useState('07:30');

  // Calculate 90-minute cycles
  // 1 cycle = 90 mins (1.5 hrs), plus 14 mins latency
  const getCycleTimes = () => {
    if (calcMode === 'wake') {
      const now = new Date();
      now.setMinutes(now.getMinutes() + 14); // latency to fall asleep
      const cycles = [
        { count: 3, hours: 4.5, label: 'Emergency Nap / Short' },
        { count: 4, hours: 6.0, label: 'Minimum Viable Sleep' },
        { count: 5, hours: 7.5, label: 'Recommended Optimal (5 Cycles)' },
        { count: 6, hours: 9.0, label: 'Full Restoration / Peak' },
      ];

      return cycles.map((c) => {
        const time = new Date(now.getTime() + c.hours * 60 * 60 * 1000);
        return {
          ...c,
          timeString: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      });
    } else {
      // Calculate bedtimes based on target wake time
      const [hours, minutes] = targetWakeTime.split(':').map(Number);
      const wakeDate = new Date();
      wakeDate.setHours(hours, minutes, 0, 0);

      const cycles = [
        { count: 6, hours: 9.0, label: 'Peak Restoration (6 Cycles)' },
        { count: 5, hours: 7.5, label: 'Recommended Optimal (5 Cycles)' },
        { count: 4, hours: 6.0, label: 'Minimum Acceptable (4 Cycles)' },
      ];

      return cycles.map((c) => {
        // Bedtime = WakeTime - cycles - 14 mins
        const bedTime = new Date(wakeDate.getTime() - (c.hours * 60 + 14) * 60 * 1000);
        return {
          ...c,
          timeString: bedTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
      });
    }
  };

  const calculatedTimes = getCycleTimes();

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {/* Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-surface-container border border-surface-container-high shadow-xs">
        <div className="relative min-h-[220px] sm:min-h-[260px] flex flex-col justify-end p-6 sm:p-8 text-white">
          <img
            src={ASSETS.sleepBedroom}
            alt="Circadian Evening Sleep Atmosphere"
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent" />
          
          <div className="relative z-10 space-y-2 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-semibold">
                Pillar 01 • Circadian Biology
              </span>
              <span className="text-xs text-white/80">90-Minute Ultradian Cycles</span>
            </div>
            <h1 className="font-headline text-2xl sm:text-3xl font-bold tracking-tight">
              Sleep & Circadian Rhythm Harmony
            </h1>
            <p className="text-xs sm:text-sm text-white/90">
              Waking up mid-deep sleep causes severe sleep inertia. Sync your alarm with 90-minute REM intervals to wake up effortless and energized.
            </p>
          </div>
        </div>
      </div>

      {/* Sleep Cycle Calculator */}
      <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-secondary">
              Precision Calculator
            </span>
            <h2 className="font-headline text-2xl font-bold text-on-surface">
              Circadian Cycle Calculator
            </h2>
            <p className="text-xs text-on-surface-variant mt-1">
              Based on human 90-minute REM cycles with a standard 14-minute sleep onset buffer.
            </p>
          </div>

          {/* Toggle Calculation Mode */}
          <div className="flex items-center p-1 bg-surface-container rounded-2xl border border-surface-container-high">
            <button
              onClick={() => setCalcMode('wake')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                calcMode === 'wake'
                  ? 'bg-surface-container-lowest text-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              If I Sleep Now
            </button>
            <button
              onClick={() => setCalcMode('sleep')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                calcMode === 'sleep'
                  ? 'bg-surface-container-lowest text-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              I Must Wake At...
            </button>
          </div>
        </div>

        {calcMode === 'sleep' && (
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-surface-container-low border border-surface-container max-w-sm">
            <span className="material-symbols-outlined text-secondary">alarm</span>
            <div className="flex-1">
              <label className="block text-[11px] font-bold uppercase tracking-wider text-outline">
                Desired Morning Wake Time
              </label>
              <input
                type="time"
                value={targetWakeTime}
                onChange={(e) => setTargetWakeTime(e.target.value)}
                className="font-headline text-lg font-bold bg-transparent text-on-surface focus:outline-hidden"
              />
            </div>
          </div>
        )}

        {/* Results grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {calculatedTimes.map((item, idx) => {
            const isOptimal = item.count === 5;
            return (
              <div
                key={idx}
                className={`p-5 rounded-2xl border transition-all ${
                  isOptimal
                    ? 'bg-primary-fixed/20 border-primary shadow-xs ring-2 ring-primary/20'
                    : 'bg-surface-container-lowest border-surface-container-high hover:border-surface-container-highest'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-on-surface-variant mb-1">
                  <span className="font-semibold">{item.count} Full Cycles</span>
                  {isOptimal && (
                    <span className="px-2 py-0.5 rounded-full bg-primary text-white text-[10px] font-bold">
                      Golden Ratio
                    </span>
                  )}
                </div>
                <div className="font-headline text-3xl font-extrabold text-on-surface my-1">
                  {item.timeString}
                </div>
                <div className="text-xs text-on-surface-variant font-medium">
                  {item.hours} hours total sleep
                </div>
                <div className="text-[11px] text-outline mt-2 pt-2 border-t border-surface-container">
                  {item.label}
                </div>
              </div>
            );
          })}
        </div>

        <p className="text-xs text-on-surface-variant bg-surface-container-low p-3.5 rounded-2xl border border-surface-container">
          <strong>Tip:</strong> If you wake up between sleep cycles at 5 or 6 intervals, your brain is in stage 1 light sleep, completely eliminating grogginess and morning brain fog.
        </p>
      </div>

      {/* Dorm Sleep Hygiene Checklist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-primary-fixed/50 text-on-primary-fixed flex items-center justify-center">
              <span className="material-symbols-outlined">nightlight</span>
            </div>
            <div>
              <h3 className="font-headline font-bold text-base text-on-surface">
                Dorm Evening Wind-Down Rules
              </h3>
              <p className="text-xs text-on-surface-variant">45 minutes before sleep</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-on-surface-variant">
            <div className="flex items-start gap-3 p-3 rounded-xl bg-surface-container-low">
              <span className="material-symbols-outlined text-amber-600 text-lg">wb_incandescent</span>
              <div>
                <strong className="text-on-surface block">Cut Blue Screen Glare:</strong>
                Switch laptop and phone to Warm Night Shift mode or wear blue-light blocking glasses after 9 PM.
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl bg-surface-container-low">
              <span className="material-symbols-outlined text-secondary text-lg">thermostat</span>
              <div>
                <strong className="text-on-surface block">Cool Down Room Temperature:</strong>
                Optimal sleep temperature is 18°C (65°F). Body temperature must drop 1°C to initiate slow-wave sleep.
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl bg-surface-container-low">
              <span className="material-symbols-outlined text-primary text-lg">local_cafe</span>
              <div>
                <strong className="text-on-surface block">The 2 PM Caffeine Curfew:</strong>
                Caffeine has a 6-to-8 hour metabolic half-life. Afternoon energy drinks block adenosine receptors well into the night.
              </div>
            </div>
          </div>
        </div>

        {/* Circadian Clock Phase Info */}
        <div className="bg-surface-container-lowest rounded-3xl border border-surface-container-high p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-secondary-container/30 text-secondary flex items-center justify-center">
              <span className="material-symbols-outlined">schedule</span>
            </div>
            <div>
              <h3 className="font-headline font-bold text-base text-on-surface">
                Circadian Chronobiology Rhythm
              </h3>
              <p className="text-xs text-on-surface-variant">Daily hormonal cycles</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-on-surface-variant">
            <div className="p-3 rounded-xl border border-surface-container">
              <div className="flex items-center justify-between font-semibold text-on-surface mb-1">
                <span>07:00 – 09:00 AM • Cortisol Awakening</span>
                <span className="text-emerald-700">Highest Alertness</span>
              </div>
              <p>Natural cortisol spike prompts wakefulness. Best time for bright morning light.</p>
            </div>

            <div className="p-3 rounded-xl border border-surface-container">
              <div className="flex items-center justify-between font-semibold text-on-surface mb-1">
                <span>10:00 AM – 01:00 PM • Peak Cognitive Window</span>
                <span className="text-secondary">Study Sprint</span>
              </div>
              <p>Prefrontal cortex executive function peaks. Tackle difficult calculus, essays, or code.</p>
            </div>

            <div className="p-3 rounded-xl border border-surface-container">
              <div className="flex items-center justify-between font-semibold text-on-surface mb-1">
                <span>09:30 PM • Melatonin Secretion Starts</span>
                <span className="text-indigo-700">Wind-Down</span>
              </div>
              <p>Pineal gland releases melatonin as ambient light wanes. Prepare bedroom for sleep.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
