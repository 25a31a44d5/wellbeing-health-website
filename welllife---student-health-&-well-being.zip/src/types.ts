export type ScreenId =
  | 'home'
  | 'health-assessment'
  | 'healthy-habits'
  | 'mental-wellness'
  | 'sleep'
  | 'nutrition'
  | 'exercise'
  | 'dashboard'
  | 'about'
  | 'contact';

export interface UserHabit {
  id: string;
  title: string;
  category: 'sleep' | 'hydration' | 'movement' | 'mindfulness' | 'nutrition';
  target: string;
  completed: boolean;
  streakDays: number;
}

export interface AssessmentAnswers {
  sleepQuality?: string;
  stressLevel?: number;
  physicalActivity?: string;
  nutritionBalance?: string;
  screenTimeHours?: number;
  mindfulnessFrequency?: string;
}

export interface UserProfile {
  name: string;
  university: string;
  major: string;
  overallScore: number;
  streak: number;
  weeklyGoalProgress: number;
}
